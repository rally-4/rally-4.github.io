local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_poly2(meshes[1],{0,0,0},8,0xa08060ff,24,32,8)
gfx.add_circle2(meshes[1],{0,0,0},0xffbf00ff,24*math.cos(180/8))