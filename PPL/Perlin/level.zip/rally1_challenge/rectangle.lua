local width=512
local height=256
meshes={{
    vertexes={{-256,-128,0},{-256,128,0},{256,128,0},{256,-128,0}},
    colors={0xffffffff,0xffffffff,0xffffffff,0xffffffff},
    segments={{0,1,2,3,0}}
}}