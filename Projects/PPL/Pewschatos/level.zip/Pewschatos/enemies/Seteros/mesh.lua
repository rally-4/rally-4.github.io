local gfx = require("/dynamic/helpers/graphic_helpers.lua")
local phi = (1 + 5^0.5)/2
local scl = 64
meshes={{
    vertexes={
        {0,1*scl,phi*scl},{0,-1*scl,phi*scl},{0,1*scl,-phi*scl},{0,-1*scl,-phi*scl},
        {1*scl,phi*scl,0},{-1*scl,phi*scl,0},{1*scl,-phi*scl,0},{-1*scl,-phi*scl,0},
        {phi*scl,0,1*scl},{phi*scl,0,-1*scl},{-phi*scl,0,1*scl},{-phi*scl,0,-1*scl}
    },
    colors={
        0xa850b0bf,0xa850b0bf,0xa850b0bf,0xa850b0bf,
        0xa850b0bf,0xa850b0bf,0xa850b0bf,0xa850b0bf,
        0xa850b0bf,0xa850b0bf,0xa850b0bf,0xa850b0bf
    },
    segments={
        {0,2}, {0,6}, {0,7}, {0,9}, {0,11},
        {1,3}, {1,4}, {1,5}, {1,9}, {1,11},
        {2,6}, {2,7}, {2,8}, {2,10},
        {3,4}, {3,5}, {3,8}, {3,10},
        {4,6}, {4,10}, {4,11},
        {5,7}, {5,8}, {5,9},
        {6,10}, {6,11},
        {7,9},
        {8,7}, {8,10},
        {9,11}
    }
}}
gfx.add_sphere(meshes[1],{0,0,0},0xa850b0bf,24)