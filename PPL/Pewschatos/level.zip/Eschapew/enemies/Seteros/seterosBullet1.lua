local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local SB1={}
function SB1.new(x,y,ship,dx,dy)
    local sb1=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(sb1,"/dynamic/enemies/Seteros/bulletMesh1.lua",0)
    pewpew.customizable_entity_start_spawning(sb1,0)
    pewpew.entity_set_radius(sb1,15fx)
    pewpew.customizable_entity_set_position_interpolation(sb1,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    pewpew.entity_set_update_callback(sb1,function()
        t=t+1
        roll=roll+(fmath.abs_fixedpoint(dx)+dy)/32fx
        local ex,ey=pewpew.entity_get_position(sb1)
        if not dead then
            pewpew.entity_set_position(sb1,ex+dx,ey-dy)
            pewpew.customizable_entity_set_mesh_angle(sb1,roll,1fx,1fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(sb1,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(sb1,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(sb1,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(sb1,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(sb1,function()
        pewpew.customizable_entity_start_exploding(sb1,12)
        pewpew.add_damage_to_player_ship(ship,1)
        dead=true
    end)
    return sb1
end
return SB1