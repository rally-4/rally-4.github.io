local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local EB3={}
function EB3.new(x,y,ship,speed,angle)
    local eb3=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(eb3,"/dynamic/enemies/Erus/bulletMesh3.lua",0)
    pewpew.customizable_entity_start_spawning(eb3,0)
    pewpew.entity_set_radius(eb3,6fx)
    pewpew.customizable_entity_set_position_interpolation(eb3,true)
    local t = 0
    local roll = fmath.tau()
    local dx,dy = fmath.sincos(angle)
    dx = dx*speed
    dy = dy*speed
    local dead = false
    pewpew.entity_set_update_callback(eb3,function()
        t=t+1
        roll=roll+(dx+dy)/32fx
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(eb3,angle,1fx,0fx,0fx)
        end
        local ex,ey=pewpew.entity_get_position(eb3)
        if not dead then
            pewpew.entity_set_position(eb3, ex+dx, ey+dy)
            pewpew.customizable_entity_set_mesh_angle(eb3,roll,1fx,1fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(eb3,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(eb3,6)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(eb3,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(eb3,6)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(eb3,function()
        pewpew.customizable_entity_start_exploding(eb3,6)
        pewpew.add_damage_to_player_ship(ship,1)
        dead = true
    end)
end
return EB3