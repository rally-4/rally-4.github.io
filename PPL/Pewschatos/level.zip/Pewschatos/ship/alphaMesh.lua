meshes={{
    vertexes={{-10,0},{-5,6,3},{15,0},{-5,-6,3},{-1,13},{14,8},{-1,18,4},{-13,8},{-1,-13},{14,-8},{-1,-18,4},{-13,-8}},
    colors={0xffff00ff,0xffff00ff,0xffff00ff,0xffff00ff,0xffbb00df,0xffbb00df,0xffbb00df,0xffbb00df,0xffbb00df,0xffbb00df,0xffbb00df,0xffbb00df},
    segments={{0,1,2,3,0},{4,5,6,7,4},{8,9,10,11,8}}
}}