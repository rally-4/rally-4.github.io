local eh = require("/dynamic/helpers/enemy_helpers.lua")
local ch = require("/dynamic/helpers/color_helpers.lua")
local BAF={}
function BAF.new(x,y,ship,speed,angle,health)
    local baf=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.BAF,baf)
    pewpew.customizable_entity_set_mesh(baf,"/dynamic/enemies/BAF/meshes.lua",0)
    pewpew.entity_set_radius(baf,24fx)
    pewpew.customizable_entity_set_position_interpolation(baf,true)
    local t = 0
    local dy,dx = fmath.sincos(angle)
    local roll = fmath.tau()
    local dead = false
    local cyan = false
    local activated = false
    local r = 90
    local coloring = true
    pewpew.entity_set_update_callback(baf,function()
        t=t+1
        roll=roll+speed/25fx
        local ex,ey=pewpew.entity_get_position(baf)
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(baf,angle,0fx,0fx,1fx)
        end
        if t == 30 then
            activated = true
        end
        if not dead and activated then
            pewpew.entity_set_position(baf,ex+(dx*speed),ey+(dy*speed))
            pewpew.customizable_entity_set_mesh_angle(baf,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(baf,angle,0fx,0fx,1fx)
        end
        
        if not coloring then
            r=r-1
        else
            r=r+1
        end
        if r > 120 then
            coloring = false
        end
        if r < 60 then
            coloring = true
        end
        local g = 255
        local b = r/2//1
        if cyan then b=b*4 end
        pewpew.customizable_entity_set_mesh_color(baf,ch.make_color(r,g,b,255))
    end)
    pewpew.customizable_entity_configure_wall_collision(baf,true,function(entity_id,normal_x,normal_y)
        local dpm = ((normal_x*dx) + (normal_y*dy))*2fx
        dx = dx - (normal_x * dpm)
        dy = dy - (normal_y * dpm)
        angle = fmath.atan2(dy,dx)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(baf,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION and not cyan then
            pewpew.customizable_entity_set_mesh_scale(baf,1fx/2fx)
            pewpew.entity_set_radius(baf,12fx)
            health = 1
            cyan = true
            dx = dx * 2fx
            dy = dy * 2fx
        elseif weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not dead then
            pewpew.customizable_entity_start_exploding(baf,30)
            pewpew.increase_score_of_player(0,20)
            dead = true
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health=health-1
            if health < 1 and not dead then
                if not cyan then
                    pewpew.create_explosion(select(1,pewpew.entity_get_position(baf)),select(2,pewpew.entity_get_position(baf)),0x96ff48ff,1fx,16)
                else
                    pewpew.create_explosion(select(1,pewpew.entity_get_position(baf)),select(2,pewpew.entity_get_position(baf)),0x96ffbfff,1fx/2fx,16)
                end
                pewpew.customizable_entity_start_exploding(baf,30)
                pewpew.increase_score_of_player(0,20)
                dead = true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(baf,function()
        if activated and not dead then
            pewpew.customizable_entity_start_exploding(baf,30)
            pewpew.add_damage_to_player_ship(ship,1)
            pewpew.increase_score_of_player(0,20)
            dead = true
        end
    end)
    return baf
end
return BAF