local eh = require("/dynamic/helpers/enemy_helpers.lua")
local ch = require("/dynamic/helpers/color_helpers.lua")
local BAF = require("/dynamic/enemies/BAF/BAF.lua")
local WBAF = require("/dynamic/enemies/WBAF/WBAF.lua")
local OBAF = require("/dynamic/enemies/OBAF/OBAF.lua")
local VATER = require("/dynamic/enemies/VATER/VATER.lua")
local wave = require("/dynamic/wave.lua")
local math = require("/dynamic/math.lua")
local width = 768fx
local height = 768fx
local rw = width/2fx
local rh = height/2fx
pewpew.set_level_size(width,height)

local outline = pewpew.new_customizable_entity(0fx,0fx)
pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/outline.lua",0)
local bg = pewpew.new_customizable_entity(rw,rh)
pewpew.customizable_entity_set_mesh(bg,"/dynamic/bg/bg.lua",0)

pewpew.configure_player(0,{shield=3,move_joystick_color=0xffffffff,shoot_joystick_color=0x88ff88ff})
local ship = pewpew.new_player_ship(rw,rh,0)
pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_5,cannon=pewpew.CannonType.DOUBLE_SWIPE})
pewpew.configure_player_hud(0,{top_left_line="Stage 1"})

local blacklist = {outline, bg, ship}
function check(id)
    local ver=true
    for _,e in ipairs(blacklist) do
        if e==id then ver=false end
    end
    -- pewpew.print(id .. ": " .. tostring(ver))
    return ver
end

local t=0
local t_baf=9999
local t_wbaf=180
local t_vater=330
local speed=6fx
local stage=1
function tick()
    t=t+1
    local conf=pewpew.get_player_configuration(0)
    if conf["has_lost"]==true then
        pewpew.stop_game()
    end
    
    local x = fmath.random_fixedpoint(32fx,736fx)
    if x<rw then x=(x+32fx)/2fx else x=(x+736fx)/2fx end
    local y = fmath.random_fixedpoint(32fx,736fx)
    if y<rh then y=(y+32fx)/2fx else y=(y+736fx)/2fx end
    local px,py = pewpew.entity_get_position(ship)
    local ang = fmath.random_fixedpoint(0fx,fmath.tau())
    
    if t % t_wbaf == 0 then
        local dir = wave.directions[fmath.random_int(1,#wave.directions)]
        wave.type.WBAF(width, height, dir, 48, speed, ship)
    end
    if t % t_vater == 0 then
        VATER.new(x, y, ship, 10)
    end
    if t % t_baf == 0 then
        BAF.new(width-x, height-y, ship, 4fx, ang, 5)
    end
    if t % (301-t_baf) == 0 and stage > 2 then
        OBAF.new(x, y, ship, 8fx, ang)
    end
    if t % 77 == 0 and stage == 5 then
        pewpew.new_rolling_sphere(x, y, ang, speed/2fx)
    end
    
    if t % t_wbaf == 0 then
        bid=pewpew.new_bonus(px,py,pewpew.BonusType.SHIELD,{box_duration=300,number_of_shields=1})
        if stage<3 then t_wbaf = math.ceil(t_wbaf/1.04) end
        speed=speed+1fx/4fx
    end
    if t % 1200 == 0 and stage > 1 then
        local rx = fmath.random_fixedpoint(0fx,width)
        local ry = fmath.random_fixedpoint(0fx,height)
        pewpew.new_bomb(rx, ry, pewpew.BombType.FREEZE)
    end
    if t % 930 == 0 and stage > 3 then
        local rx = fmath.random_fixedpoint(0fx,width)
        local ry = fmath.random_fixedpoint(0fx,height)
        pewpew.new_bomb(rx, ry, pewpew.BombType.SMALL_ATOMIZE)
    end
    
    if t == 1800 and stage == 1 then
        t = 1
        t_baf = 150
        t_wbaf = 210
        speed = 6fx
        t_vater = 300
        for _,id in ipairs(pewpew.get_all_entities()) do
            local et=pewpew.get_entity_type(id)
            if check(id) and et==pewpew.EntityType.CUSTOMIZABLE_ENTITY then
                local cx,cy=pewpew.entity_get_position(id)
                pewpew.create_explosion(cx,cy,0xffffffff,1fx,16)
                pewpew.entity_destroy(id)
            end
        end
        pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_6,cannon=pewpew.CannonType.DOUBLE_SWIPE})
        pewpew.configure_player_hud(0,{top_left_line="#48ff24ffStage 2"})
        pewpew.customizable_entity_set_mesh(bg,"/dynamic/bg/bg2.lua",0)
        stage = 2
    end
    if t == 2010 and stage == 2 then
        t = 1
        t_baf = 60
        t_wbaf = 240
        speed = 4fx
        t_vater = 270
        for _,id in ipairs(pewpew.get_all_entities()) do
            local et=pewpew.get_entity_type(id)
            if check(id) and et==pewpew.EntityType.CUSTOMIZABLE_ENTITY then
                local cx,cy=pewpew.entity_get_position(id)
                pewpew.create_explosion(cx,cy,0xffffffff,1fx,16)
                pewpew.entity_destroy(id)
            end
        end
        pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_7_5,cannon=pewpew.CannonType.DOUBLE_SWIPE})
        pewpew.configure_player_hud(0,{top_left_line="#ff8000ffStage 3"})
        pewpew.customizable_entity_set_mesh(bg,"/dynamic/bg/bg3.lua",0)
        stage = 3
    end
    if t == 2670 and stage == 3 then
        t = 1
        t_baf = 120
        t_wbaf = 180
        speed = 8fx
        t_vater = 240
        for _,id in ipairs(pewpew.get_all_entities()) do
            local et=pewpew.get_entity_type(id)
            if check(id) and et==pewpew.EntityType.CUSTOMIZABLE_ENTITY then
                local cx,cy=pewpew.entity_get_position(id)
                pewpew.create_explosion(cx,cy,0xffffffff,1fx,16)
                pewpew.entity_destroy(id)
            end
        end
        pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_10,cannon=pewpew.CannonType.DOUBLE_SWIPE})
        pewpew.configure_player_hud(0,{top_left_line="#8800ffffStage 4"})
        pewpew.customizable_entity_set_mesh(bg,"/dynamic/bg/bg4.lua",0)
        stage = 4
    end
    if t == 2970 and stage == 4 then
        t = 1
        t_baf = 180
        t_wbaf = 150
        speed = 12fx
        t_vater = 210
        for _,id in ipairs(pewpew.get_all_entities()) do
            local et=pewpew.get_entity_type(id)
            if check(id) and et==pewpew.EntityType.CUSTOMIZABLE_ENTITY then
                local cx,cy=pewpew.entity_get_position(id)
                pewpew.create_explosion(cx,cy,0xffffffff,1fx,16)
                pewpew.entity_destroy(id)
            end
        end
        pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_15,cannon=pewpew.CannonType.DOUBLE_SWIPE})
        pewpew.configure_player_hud(0,{top_left_line="#ff0000ffStage 5"})
        pewpew.customizable_entity_set_mesh(bg,"/dynamic/bg/bg5.lua",0)
        stage = 5
    end
end
pewpew.add_update_callback(tick)