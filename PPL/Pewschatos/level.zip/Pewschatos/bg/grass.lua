meshes={{
    vertexes={{-1,0,-1},{-1,1,-1},{1,1,-1},{1,0,-1}},
    colors={0xffffffff,0xffffffff,0xffffffff,0xffffffff},
    segments={{0,1,2,3,0}}
}}