local col = 0xff0000ff

local verts = {}
local cols = {}
local segs = {}

for n=0,4 do
    for x=-32,1056,64 do
        table.insert(verts, {x, 1024 + 32*math.random()-16, 64*math.random()})
        table.insert(verts, {x, 0 - 32*math.random()+16, 64*math.random()})
        table.insert(cols, col + 0x080000*math.random(0,4) + 0x0800*math.random(0,4))
        table.insert(cols, col + 0x080000*math.random(0,4) + 0x0800*math.random(0,4))
        if n~=0 then
            table.insert(segs, {#verts-4,#verts-2})
            table.insert(segs, {#verts-3,#verts-1})
        end
    end
end
for n=0,4 do
    for y=-32,1056,64 do
        table.insert(verts, {1024 + 32*math.random()-16, y, 64*math.random()})
        table.insert(verts, {0 - 32*math.random()+16, y, 64*math.random()})
        table.insert(cols, col + 0x080000*math.random(0,4) + 0x0800*math.random(0,4))
        table.insert(cols, col + 0x080000*math.random(0,4) + 0x0800*math.random(0,4))
        if n~=0 then
            table.insert(segs, {#verts-4,#verts-2})
            table.insert(segs, {#verts-3,#verts-1})
        end
    end
end

for m=34,510,34 do
    local z = (m/48)^3 - 256
    table.insert(verts, {-m,1024+m,z})
    table.insert(verts, {1024+m,1024+m,z})
    table.insert(verts, {1024+m,-m,z})
    table.insert(verts, {-m,-m,z})
    local col = 0xff000000 + m/2
    table.insert(cols, col)
    table.insert(cols, col)
    table.insert(cols, col)
    table.insert(cols, col)
    table.insert(segs, {#verts-4,#verts-3,#verts-2,#verts-1,#verts-4})
end

meshes={{vertexes=verts, colors=cols, segments=segs}}