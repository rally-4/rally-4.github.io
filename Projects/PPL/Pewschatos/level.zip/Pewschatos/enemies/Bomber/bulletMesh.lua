meshes={{
    vertexes={{-16,0,0},{16,0,0},{0,-16,0},{0,16,0},{0,0,-16},{0,0,16}},
    colors={0xffbf40ff,0xffbf40ff,0xffbf40ff,0xffbf40ff,0xffbf40ff,0xffbf40ff},
    segments={{0,1},{2,3},{4,5}}
}}