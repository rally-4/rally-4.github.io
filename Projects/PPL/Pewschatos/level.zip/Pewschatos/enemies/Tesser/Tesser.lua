local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local TB = require("/dynamic/enemies/Tesser/tesserBullet.lua")
local Tesser={}
function Tesser.new(x,y,width,minheight,maxheight,ship,health,angle)
    local tesser=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Tesser,tesser)
    pewpew.customizable_entity_set_mesh(tesser,"/dynamic/enemies/Tesser/mesh.lua",0)
    pewpew.entity_set_radius(tesser,12fx)
    pewpew.customizable_entity_set_position_interpolation(tesser,false)
    local t=0
    local dead=false
    pewpew.entity_set_update_callback(tesser,function()
        t=t+1
        if not dead then
            pewpew.customizable_entity_add_rotation_to_mesh(tesser,angle/32fx,1fx,0fx,0fx)
        end
        if not dead and t % 9 == 0 and t % 120 < 75 then
            local nx = fmath.random_fixedpoint(12fx, width-12fx)
            local ny = fmath.random_fixedpoint(minheight, maxheight)
            pewpew.entity_set_position(tesser, nx, ny)
            pewpew.customizable_entity_add_rotation_to_mesh(tesser,angle,0fx,2fx,0fx)
            local px,py = pewpew.entity_get_position(ship)
            TB.new(nx,ny,ship,12fx,fmath.atan2(px-nx,py-ny))
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(tesser,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(tesser,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION then
            pewpew.create_explosion(select(1,pewpew.entity_get_position(tesser)),select(2,pewpew.entity_get_position(tesser)),0xff8000ff,1fx/2fx,8)
            pewpew.customizable_entity_start_exploding(tesser,15)
            pewpew.increase_score_of_player(0,30)
            pewpew.entity_destroy(tesser)
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health < 1 then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(tesser)),select(2,pewpew.entity_get_position(tesser)),0xff8000ff,1fx/2fx,8)
                pewpew.customizable_entity_start_exploding(tesser,15)
                pewpew.increase_score_of_player(0,30)
                pewpew.entity_destroy(tesser)
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(tesser,function()
        pewpew.customizable_entity_start_exploding(tesser,15)
        pewpew.increase_score_of_player(0,30)
        pewpew.add_damage_to_player_ship(ship,2)
        dead = true
    end)
    return tesser
end
return Tesser