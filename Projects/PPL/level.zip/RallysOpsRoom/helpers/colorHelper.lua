local ch={}
function ch.makeColor(r,g,b,a)
    local col=r*256+g
    col=col*256+b
    col=col*256+a
    return col
end
function ch.changeAlpha(col,a)
    col=col-col%256+a
    return col
end
function ch.fmakeColor(r,g,b,a)
    local col=fmath.to_int(r)*256+fmath.to_int(g)
    col=col*256+fmath.to_int(b)
    col=col*256+fmath.to_int(a)
    return col
end
function ch.colorToString(col)
    local s=string.format("%x",col)
    while string.len(s)<8 do s="0"..s end
    return "#"..s
end
return ch