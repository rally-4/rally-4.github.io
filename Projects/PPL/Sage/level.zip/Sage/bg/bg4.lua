local width = 384
local height = 384
local gfx=require("/dynamic/helpers/graphic_helpers.lua")
meshes={{
    vertexes={
        {128-width,-height},{-width,128-height},
        {width-128,-height},{width,128-height},
        {128-width,height},{-width,height-128},
        {width-128,height},{width,height-128}
    },
    colors={0xbf88ff88,0xbf88ff88,0xbf88ff88,0xbf88ff88,0xbf88ff88,0xbf88ff88,0xbf88ff88,0xbf88ff88},
    segments={{0,1},{2,3},{4,5},{6,7}}
}}
gfx.add_star2(meshes[1],{0,0,0},7,0xffffffff,382,math.pi/2)
gfx.addFlatPoly(meshes[1],{0,0,0},7,0xbf88ffff,384,math.pi/2)
gfx.add_circle(meshes[1],{0,0,0},0xffffffff,384)
gfx.implementCircumference(meshes[1],{0,0,0},0xbf88ff88,320,64,14,math.pi/4,math.pi/2)
gfx.implementCircumference(meshes[1],{0,0,0},0xbf88ff88,256,64,7,math.pi/2,math.pi/2)