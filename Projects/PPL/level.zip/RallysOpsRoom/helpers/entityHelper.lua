local entity={}
local entityInfo={}
entity.types={
    
}
entity.parameters={category=1}
function entity.addEntityInfo(id,type)
    entityInfo[id]={type}
end
function entity.changeParam(id,param,v)
    entityInfo[id][param]=v
end
function entity.getEntityInfo(id)
    if entityInfo[id]~=nil then return entityInfo[id] end return {}
end
function entity.removeInfo(id) entityInfo[id]=nil end
function entity.get_angle_to_player(ship,id)
    local px,py=pewpew.entity_get_position(ship)
    local ex,ey=pewpew.entity_get_position(id)
    local dx,dy=ex-px,ey-py
    local ang=fmath.atan2(dy,dx)
    return ang
end
return entity