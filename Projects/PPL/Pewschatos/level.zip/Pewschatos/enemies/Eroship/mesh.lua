local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_poly2(meshes[1],{0,0,0},32,0x404040ff,256,128,64)
gfx.add_poly2(meshes[1],{0,0,0},32,0xbf0040df,248,120,64)