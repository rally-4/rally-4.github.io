-- ༼ つ ◕_◕ ༽つ

--[[
    For whichever reason, an error is seldom thrown regarding Glaive's `ship` variable being nil,
    which isn't the case, because otherwise the entity wouldn't work properly.
    I have found no consistent way of replicating this error, it just shows up in some runs of
    Heterodyne Encounter.
--]]

local EI = require("/dynamic/helpers/entityHelper.lua")
local ch = require("/dynamic/helpers/colorHelper.lua")

local sfx = require("/dynamic/sfx/sfx.lua")
local math = require("/dynamic/math.lua")
local Text = require("/dynamic/text.lua")

local BAF = require("/dynamic/entities/BAF/BAF.lua")
local Acec = require("/dynamic/entities/Acec/Acec.lua")

local Glaive = require("/dynamic/entities/Glaive/Glaive.lua")
local Regtei = require("/dynamic/entities/Regtei/Regtei.lua")

-- I wanted to add a recoil effect for the booster weapon, but realised it would allow the player to phase through walls.
local function booster(px,py,sa)
    pewpew.new_player_bullet(px,py,sa-5fx*math.fpi/6fx,0)
    pewpew.new_player_bullet(px,py,sa-3fx*math.fpi/4fx,0)
    pewpew.new_player_bullet(px,py,sa,0)
    pewpew.new_player_bullet(px,py,sa+3fx*math.fpi/4fx,0)
    pewpew.new_player_bullet(px,py,sa+5fx*math.fpi/6fx,0)
end
local function revengeBlast(px,py,n)
    local rang=fmath.random_fixedpoint(0fx,math.fpi/2fx)
    for ang=rang, math.ftau-math.ftau/n+rang, math.ftau/n do
        pewpew.new_player_bullet(px,py,ang,0)
    end
end
local function scatter(px,py,sa)
    local rang=fmath.random_fixedpoint(sa-math.fpi/8fx,sa+math.fpi/8fx)
    pewpew.new_player_bullet(px,py,rang,0)
end
local function RF(px,py,sa)
    for _=1,12 do pewpew.new_player_bullet(px,py,sa,0) end
end

local ship = pewpew.new_player_ship(512fx, 512fx, 0)
pewpew.configure_player(0, {shield = 3})
local w = 1024fx + 2fx
local h = 1024fx + 2fx
local rw = w/2fx
local rh = h/2fx
pewpew.set_level_size(w,h)

local t = 0

local stage = 0
local S1req = 5000
local BAFcount = 4
local S2T = 30
local sc = 0
local RFcool = 20
local killCount = 0
local stagesCompleted = 0
local wave = 0
local enemies = {}
local sd2 = 1fx

local walls={}
function cleanse()
    local l=pewpew.get_all_entities()
    for _,e in ipairs(l) do
        local t=pewpew.get_entity_type(e)
        if t~=pewpew.EntityType.SHIP then pewpew.entity_destroy(e) end
    end
    for _,w in ipairs(walls) do
        pewpew.remove_wall(w)
    end
    walls={}
end

-- S1: Classic
function S1_vernalCliffside()
    cleanse() stage = 1
    
    local outline=pewpew.new_customizable_entity(1fx,1fx)
    pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/vernalCliffside/outline.lua",0)
    local cones=pewpew.new_customizable_entity(1fx,1fx)
    pewpew.customizable_entity_set_mesh(cones,"/dynamic/bg/vernalCliffside/cones.lua",0)
    
    pewpew.new_bonus(641fx,833fx,pewpew.BonusType.SHIELD,{box_duration=300})
    
    pewpew.entity_set_position(ship,rw,rh/2fx)
    pewpew.set_player_ship_speed(ship,1fx,0fx,-1)
    pewpew.configure_player(0,{camera_distance=64fx,move_joystick_color=0x40ff4080,shoot_joystick_color=0x60ffff80})
    pewpew.configure_player_ship_weapon(ship,{})
    
    walls={pewpew.add_wall(1024fx + 1fx, 1024fx + 1fx, 1024fx + 1fx, 384fx + 1fx),
    pewpew.add_wall(1024fx + 1fx, 384fx + 1fx, 768fx + 1fx, 384fx + 1fx),
    pewpew.add_wall(768fx + 1fx, 384fx + 1fx, 768fx + 1fx, 0fx),
    pewpew.add_wall(768fx + 1fx, 0fx + 1fx, 128fx + 1fx, 0fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 0fx + 1fx, 128fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 256fx + 1fx, 0fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 256fx + 1fx, 0fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 896fx + 1fx, 256fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(256fx + 1fx, 896fx + 1fx, 256fx + 1fx, 1024fx + 1fx),
    pewpew.add_wall(256fx + 1fx, 1024fx + 1fx, 1024fx + 1fx, 1024fx + 1fx),
    
    pewpew.add_wall(320fx + 1fx, 704fx + 1fx, 448fx + 1fx, 704fx + 1fx),
    pewpew.add_wall(448fx + 1fx, 704fx + 1fx, 448fx + 1fx, 320fx + 1fx),
    pewpew.add_wall(448fx + 1fx, 320fx + 1fx, 192fx + 1fx, 320fx + 1fx),
    pewpew.add_wall(192fx + 1fx, 320fx + 1fx, 192fx + 1fx, 448fx + 1fx),
    pewpew.add_wall(192fx + 1fx, 448fx + 1fx, 320fx + 1fx, 448fx + 1fx),
    pewpew.add_wall(320fx + 1fx, 448fx + 1fx, 320fx + 1fx, 704fx + 1fx),
    
    pewpew.add_wall(576fx + 1fx, 896fx + 1fx, 704fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(704fx + 1fx, 896fx + 1fx, 704fx + 1fx, 769fx + 1fx), -- pewpew.add_wall(704fx + 1fx, 896fx + 1fx, 704fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(576fx + 1fx, 768fx + 1fx, 832fx + 1fx, 768fx + 1fx), -- pewpew.add_wall(704fx + 1fx, 768fx + 1fx, 832fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(832fx + 1fx, 768fx + 1fx, 832fx + 1fx, 640fx + 1fx),
    pewpew.add_wall(832fx + 1fx, 640fx + 1fx, 576fx + 1fx, 640fx + 1fx),
    pewpew.add_wall(576fx + 1fx, 640fx + 1fx, 576fx + 1fx, 896fx + 1fx)}
    --[[
    local r=1fx/fmath.sincos(math.fpi/8fx+math.fpi/2fx)
    for o=math.fpi/8fx,math.ftau+math.fpi/8fx,math.fpi/4fx do
        table.insert(walls, pewpew.add_wall(
            512fx * r * fmath.sincos(o + math.fpi/2fx) + 512fx,
            512fx * r * fmath.sincos(o) + 512fx,
            512fx * r * fmath.sincos(o+math.fpi/4fx + math.fpi/2fx) + 512fx,
            512fx * r * fmath.sincos(o+math.fpi/4fx) + 512fx
        ))
    end
    for o=0fx,math.ftau,math.fpi/4fx do
        table.insert(walls, pewpew.add_wall(
            128fx * r * fmath.sincos(o + math.fpi/2fx) + 512fx,
            128fx * r * fmath.sincos(o) + 512fx,
            128fx * r * fmath.sincos(o+math.fpi/4fx + math.fpi/2fx) + 512fx,
            128fx * r * fmath.sincos(o+math.fpi/4fx) + 512fx
        ))
    end
    --]]
end
-- S2: Hellish
function S2_cataclysm()
    cleanse() stage = 2
    
    w = 1024fx
    h = 1024fx
    rw = w/2fx
    rh = h/2fx
    pewpew.set_level_size(w,h)
    
    local outline=pewpew.new_customizable_entity(0fx,0fx)
    pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/cataclysm/outline.lua",0)
    local floor=pewpew.new_customizable_entity(rw,rh)
    pewpew.customizable_entity_set_mesh(floor,"/dynamic/bg/cataclysm/floor.lua",0)
    
    pewpew.entity_set_position(ship,rw,rh)
    pewpew.set_player_ship_speed(ship,1fx,2fx,-1)
    pewpew.configure_player(0,{camera_distance=-128fx,move_joystick_color=0xff008080,shoot_joystick_color=0xff800080})
    pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_1,cannon=pewpew.CannonType.HEMISPHERE})
    pewpew.configure_player_hud(0,{top_left_line="#ff2020ff30s"})
end
-- L3: Power trip
function S3_slam()
    cleanse() stage = 3
    sc = pewpew.get_score_of_player(0)
    
    w = 1536fx
    h = 1024fx
    rw = w/2fx
    rh = h/2fx
    pewpew.set_level_size(w,h)
    
    local outline=pewpew.new_customizable_entity(0fx,0fx)
    pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/slam/outline.lua",0)
    
    pewpew.entity_set_position(ship,w-4fx,rh)
    pewpew.set_player_ship_speed(ship,2fx,4fx,-1)
    pewpew.configure_player(0,{camera_distance=-256fx,move_joystick_color=0x60a0c080,shoot_joystick_color=0x40a0ff80})
    pewpew.configure_player_ship_weapon(ship,{})
    pewpew.entity_add_mace(ship,{distance=128fx, angle=0fx, rotation_speed=math.ftau/15fx, type=pewpew.MaceType.DAMAGE_ENTITIES})
    pewpew.entity_add_mace(ship,{distance=128fx, angle=math.fpi, rotation_speed=math.ftau/15fx, type=pewpew.MaceType.DAMAGE_ENTITIES})
    
    walls={pewpew.add_wall(128fx, 320fx, 256fx, 256fx),
    pewpew.add_wall(256fx, 256fx, 256fx, 128fx),
    pewpew.add_wall(256fx, 128fx, 128fx, 128fx),
    pewpew.add_wall(128fx, 128fx, 128fx, 320fx),
    
    pewpew.add_wall(1280fx, 256fx, 1408fx, 320fx),
    pewpew.add_wall(1408fx, 320fx, 1408fx, 128fx),
    pewpew.add_wall(1408fx, 128fx, 1280fx, 128fx),
    pewpew.add_wall(1280fx, 128fx, 1280fx, 256fx),
    
    pewpew.add_wall(320fx, 768fx, 576fx, 768fx),
    pewpew.add_wall(576fx, 768fx, 640fx, 640fx),
    pewpew.add_wall(640fx, 640fx, 896fx, 640fx),
    pewpew.add_wall(896fx, 640fx, 960fx, 768fx),
    pewpew.add_wall(960fx, 768fx, 1216fx, 768fx),
    pewpew.add_wall(1216fx, 768fx, 1216fx, 512fx),
    pewpew.add_wall(1216fx, 512fx, 1152fx, 384fx),
    pewpew.add_wall(1152fx, 384fx, 384fx, 384fx),
    pewpew.add_wall(384fx, 384fx, 320fx, 512fx),
    pewpew.add_wall(320fx, 512fx, 320fx, 768fx)}
end
-- L4: ???
function S4()
    cleanse() stage = 4
    
    w = 1152fx
    h = 768fx
    rw = w/2fx
    rh = h/2fx
    pewpew.set_level_size(w,h)
    
    pewpew.entity_set_position(ship,rw,3fx*h)
    pewpew.set_player_ship_speed(ship,0fx,0fx,-1)
    pewpew.configure_player(0,{camera_distance=-256fx,move_joystick_color=0xffffff00,shoot_joystick_color=0xff000080})
    pewpew.configure_player_ship_weapon(ship,{})
    pewpew.configure_player_hud(0,{top_left_line=""})
    
    walls={pewpew.add_wall(288fx, 672fx, 384fx, 672fx),
    pewpew.add_wall(384fx, 672fx, 432fx, 576fx),
    pewpew.add_wall(432fx, 576fx, 432fx, 480fx),
    pewpew.add_wall(432fx, 480fx, 336fx, 480fx),
    pewpew.add_wall(336fx, 480fx, 336fx, 576fx),
    pewpew.add_wall(336fx, 576fx, 288fx, 672fx),
    
    pewpew.add_wall(336fx, 288fx, 432fx, 288fx),
    pewpew.add_wall(432fx, 288fx, 432fx, 192fx),
    pewpew.add_wall(432fx, 192fx, 384fx, 96fx),
    pewpew.add_wall(384fx, 96fx, 288fx, 96fx),
    pewpew.add_wall(288fx, 96fx, 336fx, 192fx),
    pewpew.add_wall(336fx, 192fx, 336fx, 288fx),
    
    pewpew.add_wall(672fx, 672fx, 864fx, 672fx),
    pewpew.add_wall(864fx, 672fx, 864fx, 480fx),
    pewpew.add_wall(864fx, 480fx, 672fx, 480fx),
    pewpew.add_wall(672fx, 480fx, 672fx, 672fx),
    
    pewpew.add_wall(912fx, 672fx, 1008fx, 672fx),
    pewpew.add_wall(1008fx, 672fx, 912fx, 576fx),
    pewpew.add_wall(912fx, 576fx, 912fx, 672fx),
    
    pewpew.add_wall(672fx, 192fx, 768fx, 192fx),
    pewpew.add_wall(768fx, 192fx, 768fx, 96fx),
    pewpew.add_wall(768fx, 96fx, 672fx, 96fx),
    pewpew.add_wall(672fx, 96fx, 672fx, 192fx),
    
    pewpew.add_wall(816fx, 288fx, 912fx, 288fx),
    pewpew.add_wall(912fx, 288fx, 912fx, 96fx),
    pewpew.add_wall(912fx, 96fx, 816fx, 96fx),
    pewpew.add_wall(816fx, 96fx, 816fx, 288fx)}
end
-- Hub: the hub
function main()
    cleanse() stage = 0
    S1req = S1req + pewpew.get_score_of_player(0)
    t = 0
    
    w = 1024fx + 2fx
    h = 1024fx + 2fx
    rw = w/2fx
    rh = h/2fx
    pewpew.set_level_size(w,h)
    
    local outline=pewpew.new_customizable_entity(rw,rh)
    pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/outline.lua",0)
    local ground=pewpew.new_customizable_entity(1fx,1fx)
    pewpew.customizable_entity_set_mesh(ground,"/dynamic/bg/ground.lua",0)
    
    pewpew.entity_set_position(ship,rw,rh)
    pewpew.set_player_ship_speed(ship,1fx,0fx,-1)
    pewpew.configure_player(0,{camera_distance=0fx,move_joystick_color=0xffffff60,shoot_joystick_color=0xffffff80})
    pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_6,cannon=pewpew.CannonType.DOUBLE})
    pewpew.configure_player_hud(0,{top_left_line="#808080ff" .. stagesCompleted .. " / 2"})
    
    walls={pewpew.add_wall(128fx + 1fx, 1024fx + 1fx, 896fx + 1fx, 1024fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 1024fx + 1fx, 896fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 896fx + 1fx, 1024fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(1024fx + 1fx, 896fx + 1fx, 1024fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(1024fx + 1fx, 768fx + 1fx, 896fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 768fx + 1fx, 896fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 256fx + 1fx, 1024fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(1024fx + 1fx, 256fx + 1fx, 1024fx + 1fx, 128fx + 1fx),
    pewpew.add_wall(1024fx + 1fx, 128fx + 1fx, 896fx + 1fx, 128fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 128fx + 1fx, 896fx + 1fx, 0fx + 1fx),
    pewpew.add_wall(896fx + 1fx, 0fx + 1fx, 128fx + 1fx, 0fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 0fx + 1fx, 128fx + 1fx, 128fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 128fx + 1fx, 0fx + 1fx, 128fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 128fx + 1fx, 0fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 256fx + 1fx, 128fx + 1fx, 256fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 256fx + 1fx, 128fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 768fx + 1fx, 0fx + 1fx, 768fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 768fx + 1fx, 0fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(0fx + 1fx, 896fx + 1fx, 128fx + 1fx, 896fx + 1fx),
    pewpew.add_wall(128fx + 1fx, 896fx + 1fx, 128fx + 1fx, 1024fx + 1fx)}
    
    if S1req>0 then
        Acec.new(960fx + 1fx, 832fx + 1fx, 0x40ff40ff, S1_vernalCliffside)
        local vernalCliffsideName=pewpew.new_customizable_entity(768fx + 1fx, 832fx + 1fx + 32fx)
        pewpew.customizable_entity_set_string(vernalCliffsideName,"#40ff40ffVernal Cliffside")
        local vernalCliffsideObjective=pewpew.new_customizable_entity(768fx + 1fx, 832fx + 1fx)
        pewpew.customizable_entity_set_string(vernalCliffsideObjective,"#40ff40ffObjective: 5000 score")
        local vernalCliffsideDifficulty=pewpew.new_customizable_entity(768fx + 1fx, 832fx + 1fx - 32fx)
        pewpew.customizable_entity_set_string(vernalCliffsideDifficulty,"#40ff40ffThreat: low")
    end
    if S2T==30 then
        Acec.new(960fx + 1fx, 192fx + 1fx, 0xff2010ff, S2_cataclysm)
        local cataclysmName=pewpew.new_customizable_entity(768fx + 1fx, 192fx + 1fx + 32fx)
        pewpew.customizable_entity_set_string(cataclysmName,"#ff2010ffCataclysm")
        local cataclysmObjective=pewpew.new_customizable_entity(768fx + 1fx, 192fx + 1fx)
        pewpew.customizable_entity_set_string(cataclysmObjective,"#ff2010ffObjective: survive 30s")
        local cataclysmDifficulty=pewpew.new_customizable_entity(768fx + 1fx, 192fx + 1fx - 32fx)
        pewpew.customizable_entity_set_string(cataclysmDifficulty,"#ff2010ffThreat: high")
    end
    if killCount==0 then
        Acec.new(64fx + 1fx, 832fx + 1fx, 0x40a0ffff, S3_slam)
        local slamName=pewpew.new_customizable_entity(256fx + 1fx, 832fx + 1fx + 32fx)
        pewpew.customizable_entity_set_string(slamName,"#40a0ffffSlam")
        local slamObjective=pewpew.new_customizable_entity(256fx + 1fx, 832fx + 1fx)
        pewpew.customizable_entity_set_string(slamObjective,"#40a0ffffObjective: 857 kills")
        local slamDifficulty=pewpew.new_customizable_entity(256fx + 1fx, 832fx + 1fx - 32fx)
        pewpew.customizable_entity_set_string(slamDifficulty,"#40a0ffffThreat: extreme")
    end
    if stagesCompleted>=2 then
        Acec.new(64fx + 1fx, 192fx + 1fx, 0x808080ff, S4)
        local heterodyneEncounterName=pewpew.new_customizable_entity(256fx + 1fx, 192fx + 1fx + 32fx)
        pewpew.customizable_entity_set_string(heterodyneEncounterName,"#808080ffHeterodyne Encounter")
        local heterodyneEncounterObjective=pewpew.new_customizable_entity(256fx + 1fx, 192fx + 1fx)
        pewpew.customizable_entity_set_string(heterodyneEncounterObjective,"#808080ffObjective: unknown")
        local heterodyneEncounterDifficulty=pewpew.new_customizable_entity(256fx + 1fx, 192fx + 1fx - 32fx)
        pewpew.customizable_entity_set_string(heterodyneEncounterDifficulty,"#808080ffThreat: undefined")
    end
end
main()

local ended = false
pewpew.add_update_callback(function()
    if ended then return 0 end
    local conf = pewpew.get_player_configuration(0)
    if conf.has_lost then
        pewpew.stop_game()
        ended = true
    end
    -- pewpew.print_debug_info()
    local ma,md,sa,sd=pewpew.get_player_inputs(0)
    local px,py=pewpew.entity_get_position(ship)
    
    if stage==1 then
        -- CUSTOM WEAPON (booster)
        if t%4==0 and sd~=0fx then
            sfx.pew()
            booster(px,py,sa)
        end
        
        -- ENEMY SPAWNING
        local ang=fmath.random_fixedpoint(0fx,math.ftau)
        if t%360==0 then
            for _=1,BAFcount do
                ang=fmath.random_fixedpoint(0fx,math.ftau)
                BAF.new(rw,rh,4fx,ang)
            end
            BAFcount=BAFcount+3
        end
        t=t+1
        if t%499==0 then pewpew.new_mothership(rw,rh,pewpew.MothershipType.SIX_CORNERS,ang) end
        
        -- SCORE (win condition)
        sc=pewpew.get_score_of_player(0)
        pewpew.configure_player_hud(0,{top_left_line=ch.colorToString(ch.makeColor(255 - 255 * (sc-S1req+5000)//5000, 255, 0, 255)) .. sc-S1req+5000 .. " / 5000"})
        if sc>=S1req then
            stagesCompleted = stagesCompleted + 1
            sfx.bonus()
            S1req=-1E9
            local s=conf.shield
            pewpew.configure_player(0,{shield=s+1})
            pewpew.increase_score_of_player(0,250*s)
            local timeBonus = math.max(2700-t,0)
            pewpew.increase_score_of_player(0,timeBonus)
            main()
            pewpew.new_floating_message(rw,rh+32fx,"#ffff80ffShield bonus: +"..250*s,{dz=8fx,ticks_before_fade=45})
            pewpew.new_floating_message(rw,rh-32fx,"#40a0ffffTime bonus: +"..timeBonus,{dz=8fx,ticks_before_fade=45})
        end
    elseif stage==2 then t=t+1
        -- POINTONIUM REMOVAL
        local l=pewpew.get_all_entities()
        for _,e in ipairs(l) do
            local t=pewpew.get_entity_type(e)
            if t==pewpew.EntityType.POINTONIUM then pewpew.entity_destroy(e) end
        end
        
        -- CUSTOM WEAPONS (scatter, salvo ×2)
        if t%3==0 and sd~=0fx then
            sfx.pew()
            scatter(px,py,sa)
        end
        if t%20<8 and sd~=0fx then
            pewpew.new_player_bullet(px,py,sa-math.fpi/4fx,0)
            pewpew.new_player_bullet(px,py,sa+math.fpi/4fx,0)
        end
        
        -- ENEMY SPAWN VARIABLES
        local rx = fmath.random_fixedpoint(0fx, 1024fx)
        local ry = fmath.random_fixedpoint(0fx, 1024fx)
        if fmath.random_fixedpoint(0fx,2fx)<1fx then
            while 64fx < rx and rx < 512fx do rx = rx - 64fx end
            while 512fx <= rx and rx < 960fx do rx = rx + 64fx end
        else
            while 64fx < ry and ry < 512fx do ry = ry - 64fx end
            while 512fx <= ry and ry < 960fx do ry = ry + 64fx end
        end
        local ang = (fmath.atan2(ry-512fx, rx-512fx)+math.fpi)%math.ftau
        
        -- ENEMY SPAWNING
        if t%19==0 then
            pewpew.new_mothership_bullet(rx,ry,ang,4fx,0xff2020ff,false)
        end
        if t%29==0 then pewpew.new_inertiac(rx,ry,1fx/4fx,ang)
        elseif t%53==0 then local ufo=pewpew.new_ufo(rx,ry,1fx) pewpew.ufo_set_enable_collisions_with_walls(ufo,true)
        elseif t%71==0 then pewpew.new_mothership(rx,ry,pewpew.MothershipType.FIVE_CORNERS,ang)
        elseif t%179==0 then pewpew.new_super_mothership(rx,ry,pewpew.MothershipType.FIVE_CORNERS,ang) end
        
        -- Ａｍｂｉａｎｃｅ (or some shit idfk). It's the longest line in this entire file, I'm sure you can guess why that is... f_m_a_t_h.r_a_n_d_o_m___f_i_x_e_d_p_o_i_n_t.
         if t%3==0 then pewpew.add_particle(fmath.random_fixedpoint(32fx,w-32fx),fmath.random_fixedpoint(32fx,h-32fx),fmath.random_fixedpoint(-64fx,64fx),fmath.random_fixedpoint(-2fx,2fx),fmath.random_fixedpoint(-2fx,2fx),fmath.random_fixedpoint(-2fx,2fx),ch.makeColor(255,fmath.random_int(32,96),8,255),fmath.random_int(15,75)) end
        
        -- TIMER (win condition)
        if t%30==0 then S2T=S2T-1 pewpew.configure_player_hud(0,{top_left_line="#ff2020ff"..S2T.."s"}) end
        if S2T==0 then
            stagesCompleted = stagesCompleted + 1
            sfx.bonus()
            local s=conf.shield
            pewpew.configure_player(0,{shield=s+1})
            pewpew.increase_score_of_player(0,250*s)
            main()
            pewpew.new_floating_message(rw,rh,"#ffff80ffShield bonus: +"..250*s,{dz=8fx,ticks_before_fade=45})
        end
    elseif stage==3 then t=t+1
        -- CUSTOM WEAPON (rifle)
        -- The actual tempo rectification value would be 64.44(4), alas, a tempo of exactly 87bpm is impossible to replicate at 30tps (without rectifying the rectification or using more elaborate methods)
        if t%64~=0 then RFcool=RFcool-1 end
        if RFcool<=0 and sd~=0fx then
            sfx.pew()
            RFcool=20
            RF(px,py,sa)
        end
        
        -- ENEMY SPAWN VARIABLES
        local rx = 4fx
        local ry = rh + fmath.random_fixedpoint(-128fx,128fx)
        local kang = 0fx
        if fmath.random_int(0,1)==1 then
            rx = rw + fmath.random_fixedpoint(-64fx,64fx)
            ry = 644fx
            kang = math.fpi/2fx
        end
        local rang = fmath.random_fixedpoint(0fx,math.ftau)
        
        -- ENEMY SPAWNING
        if t <= 8220 then
            if t%13==0 then table.insert(enemies,pewpew.new_baf_blue(rx,ry,rang,12fx,-1)) end
            if t%89==0 then table.insert(enemies,pewpew.new_kamikaze(rx,ry,kang)) end
            if t%101==0 then table.insert(enemies,pewpew.new_wary(rx,ry)) end
            if t%307==0 then
                if rx==4fx then
                    table.insert(enemies,pewpew.new_mothership(rw,644fx,pewpew.MothershipType.SEVEN_CORNERS,rang))
                else
                    table.insert(enemies,pewpew.new_mothership(4fx,rh,pewpew.MothershipType.SEVEN_CORNERS,rang))
                end
                table.insert(enemies,pewpew.new_super_mothership(rx,ry,pewpew.MothershipType.SEVEN_CORNERS,rang))
            end
        end
        
        -- KILL COUNT (win condition)
        for i=#enemies,1,-1 do
            if pewpew.entity_get_is_started_to_be_destroyed(enemies[i]) then
                table.remove(enemies, i)
                killCount = killCount + 1
            end
        end
        pewpew.configure_player_hud(0,{top_left_line=ch.colorToString(ch.makeColor(0, 192*killCount//857, 255, 255)) .. killCount .. " / 857"})
        if killCount >= 857 then
            stagesCompleted = stagesCompleted + 1
            sfx.bonus()
            local s=conf.shield
            pewpew.configure_player(0,{shield=s+1})
            pewpew.increase_score_of_player(0,250*s)
            main()
            pewpew.new_floating_message(rw,rh,"#ffff80ffShield bonus: +"..250*s,{dz=8fx,ticks_before_fade=45})
        end
    elseif stage==4 then t=t+1
        if wave==0 then
            if Text.idx > #Text.obj then
                t = 0
                wave = 1
                pewpew.new_floating_message(rw/4fx,rh,"#ffc0c0ffWave 1",{dz=8fx,ticks_before_fade=45})
                local outline=pewpew.new_customizable_entity(0fx,0fx)
                pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/heterodyneEncounter/outline.lua",0)
                local obstacles=pewpew.new_customizable_entity(0fx,0fx)
                pewpew.customizable_entity_set_mesh(obstacles,"/dynamic/bg/heterodyneEncounter/obstacles.lua",0)
                local floor=pewpew.new_customizable_entity(0fx,0fx)
                pewpew.customizable_entity_set_mesh(floor,"/dynamic/bg/heterodyneEncounter/floor.lua",0)
                pewpew.entity_set_position(ship,rw/4fx,rh)
                pewpew.set_player_ship_speed(ship,1fx,3fx,-1)
                pewpew.configure_player(0,{camera_distance=0fx,move_joystick_color=0xff000080,shoot_joystick_color=0xff000080})
                pewpew.configure_player_ship_weapon(ship,{frequency=pewpew.CannonFrequency.FREQ_1,cannon=pewpew.CannonType.SHOTGUN})
                Glaive.new(ship,rw/4fx-96fx,rh+64fx)
                Regtei.new(rw/4fx-96fx,rh-64fx)
                return 0
            end
            pewpew.configure_player(0,{camera_x_override=512fx,camera_y_override=rh})
            local txt = Text.obj[Text.idx]
            if t==1 then Text.newTalk(txt[1],txt[2]) end
            if t==30 then Text.column(txt[3]) end
            if sd2==0fx and select(4,pewpew.get_player_inputs(0))~=0fx then
                Text.idx = Text.idx + 1
                Text.remove()
                t = 0
            end
            if fmath.random_fixedpoint(0fx,1fx) < 1fx/15fx then
                local rx = fmath.random_fixedpoint(0fx, 1024fx)
                local ry = fmath.random_fixedpoint(0fx, h)
                local rz = fmath.random_fixedpoint(-32fx,32fx)
                local dr = {fmath.random_int(30,120)}
                for i=1,3 do table.insert(dr, fmath.random_fixedpoint(-3fx/2fx,3fx/2fx)) end
                pewpew.add_particle(rx,ry,rz,dr[2],dr[3],dr[4],0xffffffa0,dr[1])
            end
        elseif wave==1 then
            if #enemies==0 and t>60 then
                t = 0
                wave = 2
                pewpew.new_floating_message(px,py,"#ff8080ffWave 2",{dz=8fx,ticks_before_fade=45})
                return 0
            end
            if t%15==0 and t<=60 then
                for _=1,8 do table.insert(enemies,pewpew.new_crowder(1120fx,rh)) end
            elseif t%7==0 and t<=60 then
                table.insert(enemies,pewpew.new_wary(1120fx,rh))
            end
            for i=#enemies,1,-1 do if not pewpew.entity_get_is_alive(enemies[i]) then table.remove(enemies,i) end end
        elseif wave==2 then
            if #enemies==0 and t>60 then
                t = 0
                wave = 3
                pewpew.new_floating_message(px,py,"#ff4040ffWave 3",{dz=8fx,ticks_before_fade=45})
                return 0
            end
            if t%9==0 and t<=60 then
                for _=1,6 do local e=pewpew.new_rolling_cube(1120fx,rh) pewpew.rolling_cube_set_enable_collisions_with_walls(e,true) table.insert(enemies,e) end
            elseif t%10==0 and t<=60 then
                table.insert(enemies,pewpew.new_mothership(1120fx,rh,pewpew.MothershipType.SIX_CORNERS,fmath.random_fixedpoint(0fx,math.ftau)))
            end
            for i=#enemies,1,-1 do if not pewpew.entity_get_is_alive(enemies[i]) then table.remove(enemies,i) end end
        elseif wave==3 then
            if #enemies==0 and t>60 then
                t = 0
                wave = 4
                pewpew.new_floating_message(px,py,"#ff0000ffWave 4",{dz=8fx,ticks_before_fade=45})
                return 0
            end
            if t%8==0 and t<=60 then
                table.insert(enemies,pewpew.new_inertiac(1120fx,fmath.random_fixedpoint(16fx,h-16fx),3fx/4fx,fmath.random_fixedpoint(5fx*math.fpi/6fx,7fx*math.fpi/6fx)))
            elseif t%9==0 and t<=60 then
                table.insert(enemies,pewpew.new_mothership(1120fx,rh,pewpew.MothershipType.FIVE_CORNERS,fmath.random_fixedpoint(5fx*math.fpi/6fx,7fx*math.fpi/6fx)))
            end
            for i=#enemies,1,-1 do if not pewpew.entity_get_is_alive(enemies[i]) then table.remove(enemies,i) end end
        elseif wave==4 then
            if #enemies==0 and t>120 then
                t = 0
                wave = 5
                cleanse()
                pewpew.entity_set_position(ship,rw,3fx*h)
                pewpew.set_player_ship_speed(ship,0fx,0fx,-1)
                pewpew.configure_player_ship_weapon(ship,{})
                return 0
            end
            if t%5==0 and t<=120 then
                table.insert(enemies,pewpew.new_spiny(1120fx,fmath.random_fixedpoint(16fx,h-16fx),fmath.random_fixedpoint(5fx*math.fpi/6fx,7fx*math.fpi/6fx),4fx))
            elseif t%59==0 and t<=120 then
                local e=pewpew.new_ufo(1120fx,rh,4fx)
                pewpew.ufo_set_enable_collisions_with_walls(e,true)
                for a=0fx,math.ftau-math.fpi/4fx,math.fpi/4fx do pewpew.entity_add_mace(e,{distance=112fx,angle=a,rotation_speed=math.fpi/30fx,type=pewpew.MaceType.DAMAGE_PLAYERS}) end
                table.insert(enemies,e)
            end
            for i=#enemies,1,-1 do if not pewpew.entity_get_is_alive(enemies[i]) then table.remove(enemies,i) end end
        elseif wave==5 then
            pewpew.configure_player(0,{camera_x_override=512fx,camera_y_override=rh})
            if t==30 then pewpew.new_floating_message(512fx,rh,"#40ff40ffMission Accomplished",{dz=8fx,ticks_before_fade=45}) end
            if t==90 then
                sfx.bonus()
                local s=conf.shield
                pewpew.configure_player(0,{shield=s+1})
                pewpew.increase_score_of_player(0,250*s)
                pewpew.new_floating_message(512fx,rh,"#ffff80ffShield bonus: +"..250*s,{dz=8fx,ticks_before_fade=45})
            end
            if t==150 then pewpew.add_damage_to_player_ship(ship,9999) end
        end
    end
    sd2=select(4,pewpew.get_player_inputs(0))
end)