local eh = require("/dynamic/helpers/enemy_helpers.lua")
local ch = require("/dynamic/helpers/color_helpers.lua")
local OBAF={}
function OBAF.new(x,y,ship,speed,angle)
    local obaf=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.OBAF,obaf)
    pewpew.customizable_entity_set_mesh(obaf,"/dynamic/enemies/OBAF/meshes.lua",0)
    pewpew.entity_set_radius(obaf,24fx)
    pewpew.customizable_entity_set_position_interpolation(obaf,true)
    local t = 0
    local dy,dx = fmath.sincos(angle)
    local roll = fmath.tau()
    local dead = false
    local lime = false
    local health = 10000
    local activated = false
    local g = 90
    local coloring = true
    pewpew.entity_set_update_callback(obaf,function()
        t=t+1
        roll=roll+speed/25fx
        local ex,ey=pewpew.entity_get_position(obaf)
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(obaf,angle,0fx,0fx,1fx)
        end
        if t == 30 then
            activated = true
        end
        if not dead and activated then
            pewpew.entity_set_position(obaf,ex+(dx*speed),ey+(dy*speed))
            pewpew.customizable_entity_set_mesh_angle(obaf,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(obaf,angle,0fx,0fx,1fx)
        end
        if not coloring then
            g=g-1
        else
            g=g+1
        end
        if g > 120 then
            coloring = false
        end
        if g < 60 then
            coloring = true
        end
        local r = 255
        local l = g
        local b = 0
        if lime then r=120 l=g+135 end
        pewpew.customizable_entity_set_mesh_color(obaf,ch.make_color(r,l,b,255))
    end)
    pewpew.customizable_entity_configure_wall_collision(obaf,true,function(entity_id,normal_x,normal_y)
        local dpm = ((normal_x*dx) + (normal_y*dy))*2fx
        dx = dx - (normal_x * dpm)
        dy = dy - (normal_y * dpm)
        angle = fmath.atan2(dy,dx)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(obaf,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION and not lime then
            health = 5
            lime = true
            dx = dx / 2fx
            dy = dy / 2fx
        elseif weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not dead then
            pewpew.customizable_entity_start_exploding(obaf,30)
            pewpew.increase_score_of_player(0,40)
            dead = true
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health=health-1
            if health < 1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(obaf)),select(2,pewpew.entity_get_position(obaf)),0x88ff00ff,1fx,16)
                pewpew.customizable_entity_start_exploding(obaf,30)
                pewpew.increase_score_of_player(0,40)
                dead = true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(obaf,function()
        if activated and not dead then
            pewpew.customizable_entity_start_exploding(obaf,30)
            pewpew.add_damage_to_player_ship(ship,1)
            pewpew.increase_score_of_player(0,40)
            dead = true
        end
    end)
    return obaf
end
return OBAF