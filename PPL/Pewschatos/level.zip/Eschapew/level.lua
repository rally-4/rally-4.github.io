function MakeCol(r,g,b,a)
    local col=r*256+g
    col=col*256+b
    col=col*256+a
    return col
end
function blendColors(c1,c2,t)
    local r1 = (c1 >> 24) & 0xFF
    local g1 = (c1 >> 16) & 0xFF
    local b1 = (c1 >> 8) & 0xFF
    
    local r2 = (c2 >> 24) & 0xFF
    local g2 = (c2 >> 16) & 0xFF
    local b2 = (c2 >> 8) & 0xFF
    
    local r = math.floor((1-t) * r1 + t * r2)
    local g = math.floor((1-t) * g1 + t * g2)
    local b = math.floor((1-t) * b1 + t * b2)
    return (r << 24) | (g << 16) | (b << 8) | 255
end
local BAF = require("/dynamic/enemies/BAF/BAF.lua")
local POC = require("/dynamic/enemies/POC/POC.lua")
local VATER = require("/dynamic/enemies/VATER/VATER.lua")
local Bomber = require("/dynamic/enemies/Bomber/Bomber.lua")
local Mirrain = require("/dynamic/enemies/Mirrain/Mirrain.lua")
local Eroship = require("/dynamic/enemies/Eroship/Eroship.lua")
local Tesser = require("/dynamic/enemies/Tesser/Tesser.lua")
local Erus = require("/dynamic/enemies/Erus/Erus.lua")
local Seteros = require("/dynamic/enemies/Seteros/Seteros.lua")
local Agonus = require("/dynamic/enemies/Seteros/Agonus.lua")
local Alpha = require("/dynamic/ship/Alpha.lua")
local math = require("/dynamic/math.lua")
local wave = require("/dynamic/wave.lua")

local Text = require("/dynamic/credits/Text.lua")
local txt = require("/dynamic/credits/txt.lua")

function getCenemy(id)
    for _=1,#wave.customEnemies do
        if wave.customEnemies[_]==id then
            return {true,_}
        end
    end
    return {false,nil}
end

local width = 720fx
local height = 1024fx
local rw = width/2fx
local rh = height/2fx
pewpew.set_level_size(width,height)
pewpew.add_wall(0fx,height-240fx,width,height-240fx)

local outline = pewpew.new_customizable_entity(rw,rh)
pewpew.customizable_entity_set_mesh(outline,"/dynamic/bg/outline.lua",0)
local offline = pewpew.new_customizable_entity(0fx,0fx)
pewpew.customizable_entity_set_mesh(offline,"/dynamic/bg/off.lua",0)

local at = "#ff0000ff---#ffffffff Area 1 #ff0000ff---"
local ast = {}
local astI = "ast1"
local area = 1
ast.ast1 = "SILVER LINING"
ast.ast2 = "SURVIVE"
ast.ast3 = "POINT OF NO RETURN"
ast.ast4 = "STELLAR LIGHT"
ast.ast5 = "RUSH INTO"
ast.ast6 = "EXTERMINATION"

local text = pewpew.new_customizable_entity(rw,rh-96fx)
local subtext = pewpew.new_customizable_entity(rw,rh-144fx)
pewpew.customizable_entity_set_mesh_scale(text,2fx)
pewpew.customizable_entity_set_string(text,at)
pewpew.customizable_entity_set_string(subtext,ast.ast1)
pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: 1"})

local selw = pewpew.new_customizable_entity(128fx,96fx)
pewpew.customizable_entity_set_mesh_scale(selw,1fx/2fx)
pewpew.customizable_entity_set_string(selw,"Selected weapon: #40a0dfffFront Shot")

local bg = {}
for i=0,64 do
    local _=pewpew.new_customizable_entity(fmath.random_fixedpoint(4fx,716fx),fmath.random_fixedpoint(0fx,1024fx))
    pewpew.customizable_entity_set_mesh(_,"/dynamic/bg/a1bg.lua",0)
    pewpew.customizable_entity_set_mesh_xyz_scale(_,fmath.random_fixedpoint(1fx,3fx),fmath.random_fixedpoint(1fx,3fx),1fx)
    pewpew.customizable_entity_set_position_interpolation(_,true)
    table.insert(bg,_)
end

pewpew.configure_player(0,{
    shield=3,
    move_joystick_color=0x404040ff,
    shoot_joystick_color=0xdf0020ff
})
local ship_id = pewpew.new_player_ship(rw,rh/2fx+96fx,0)
pewpew.configure_player_ship_weapon(ship_id,{})
pewpew.set_player_ship_speed(ship_id, 1fx, 5fx, -1)

local SpreadBullets={}
function newSpreadBullet(x,y,ang,l)
    local b=pewpew.new_player_bullet(x,y,ang,0)
    table.insert(SpreadBullets,{b,l})
end
local weapons={}
weapons.main = function(px,py)
    pewpew.new_player_bullet(px-16fx,py+8fx,fmath.tau()/4fx,0)
    pewpew.new_player_bullet(px-8fx,py,fmath.tau()/4fx,0)
    pewpew.new_player_bullet(px,py+12fx,fmath.tau()/4fx,0)
    pewpew.new_player_bullet(px+8fx,py,fmath.tau()/4fx,0)
    pewpew.new_player_bullet(px+16fx,py+8fx,fmath.tau()/4fx,0)
end
weapons.spreadshot = function(px,py)
    newSpreadBullet(px-12fx,py-4fx,3fx*fmath.tau()/8fx,12)
    newSpreadBullet(px-8fx,py,3fx*fmath.tau()/8fx,12)
    newSpreadBullet(px-4fx,py+8fx,3fx*fmath.tau()/8fx,12)
    newSpreadBullet(px-4fx,py+8fx,2fx*fmath.tau()/6fx,12)
    newSpreadBullet(px+4fx,py+8fx,fmath.tau()/6fx,12)
    newSpreadBullet(px+4fx,py+8fx,fmath.tau()/8fx,12)
    newSpreadBullet(px+8fx,py,fmath.tau()/8fx,12)
    newSpreadBullet(px+12fx,py-4fx,fmath.tau()/8fx,12)
end
local weaponI = "main"

function getEnemyPresence()
    local ver=true
    for _,id in ipairs(pewpew.get_all_entities()) do
        local et=pewpew.get_entity_type(id)
        if et~=pewpew.EntityType.SHIP and et~=pewpew.EntityType.PLAYER_BULLET and et~=pewpew.EntityType.CUSTOMIZABLE_ENTITY and et~=pewpew.EntityType.BOMB and et~=pewpew.EntityType.BOMB_EXPLOSION and et~=pewpew.EntityType.BONUS and et~=pewpew.EntityType.FLOATING_MESSAGE and et~=-1 or getCenemy(id)[1] then
            ver=false
        end
    end
    return ver
end

local clone = {pewpew.get_score_of_player(0)}
local cScore = clone[1]
local mul = 0
local mulBool = true
function mulsc()
    local diff=pewpew.get_score_of_player(0)-cScore
    pewpew.increase_score_of_player(0,diff*mul)
    clone={pewpew.get_score_of_player(0)}
    cScore=clone[1]
end

local t=0
local drag=8fx
local cooldown=0
local txtcol=0xff
local countdown=150
local Time=0
function tick()
    t=t+1
    local col=0xffffffff
    for j=1,#bg do
        if area==2 then
            local r=fmath.random_int(0,90)
            local g=fmath.random_int(105,150)
            local b=fmath.random_int(0,60)
            col=MakeCol(r,g,b,210)
        end
        if area==6 and countdown==150 then if t<=255 then col=blendColors(0xffffffff,0xbf0000ff,t/255) else col=0xbf0000ff end end
        if countdown<150 then if countdown>=-105 then col=blendColors(0xbf0000ff,0,(150-countdown)/255) else col=0 end end
        local x,y=pewpew.entity_get_position(bg[j])
        y=y-drag
        if area==5 then y=y+drag/2fx end
        if y < -2fx*drag-64fx then pewpew.customizable_entity_set_mesh_color(bg[j],0) end
        if y < -3fx*drag-64fx then y=y+1024fx end
        if y > 960fx-6fx*drag and y < 960fx-4fx*drag then pewpew.customizable_entity_set_mesh_color(bg[j],col) end
        pewpew.entity_set_position(bg[j],x,y)
    end
    
    for _,id in ipairs(pewpew.get_all_entities()) do
        local et = pewpew.get_entity_type(id)
        -- if et == pewpew.EntityType.POINTONIUM then
        --     pewpew.entity_destroy(id)
        -- end
        local customEnemy = getCenemy(id)[1]
        if et~=pewpew.EntityType.PLAYER_BULLET and et~=pewpew.EntityType.MOTHERSHIP_BULLET and et~=pewpew.EntityType.CUSTOMIZABLE_ENTITY and et~=pewpew.EntityType.BOMB and et~=pewpew.EntityType.BOMB_EXPLOSION and et~=pewpew.EntityType.BONUS_IMPLOSION and select(2,pewpew.entity_get_position(id))<4fx or (customEnemy and select(2,pewpew.entity_get_position(id))<4fx) then
            if customEnemy then table.remove(wave.customEnemies,getCenemy(id)[2]) end
            pewpew.configure_player_hud(0,{top_left_line="#0080ffffMultiplier: " .. (mul+1)})
            pewpew.entity_destroy(id)
            mulBool = false
        end
    end
    
    if txtcol > 0 and t > 15 then
        txtcol = txtcol-3
        at = "#" .. string.format("%x",0xff000000+txtcol) .. "---#" .. string.format("%x",0xffffff00+txtcol) .. " Area " .. area .. " #" .. string.format("%x",0xff000000+txtcol) .. "---"
        pewpew.customizable_entity_set_string(text,at)
        pewpew.customizable_entity_set_string(subtext,"#" .. string.format("%x",0xffffff00+txtcol) .. ast[astI])
    end
    
    local rem = false
    for b=#SpreadBullets,1,-1 do
        SpreadBullets[b][2] = SpreadBullets[b][2] - 1
        if SpreadBullets[b][2] < 1 and pewpew.entity_get_is_alive(SpreadBullets[b][1]) then
            pewpew.entity_destroy(SpreadBullets[b][1])
            rem = true
        end
        if not pewpew.entity_get_is_alive(SpreadBullets[b][1]) then
            rem = true
        end
        if rem then
            table.remove(SpreadBullets,b)
            rem = false
        end
    end
    cooldown=cooldown-1
    local px = select(1,pewpew.entity_get_position(ship_id))
    local py = select(2,pewpew.entity_get_position(ship_id))
    local MovAng, MovDst, ShtAng, ShtDst = pewpew.get_player_inputs(0)
    if t%2==0 and countdown>30 then weapons[weaponI](px,py) end
    if ShtDst>0fx and cooldown<=0 then
        if weaponI == "main" then
            weaponI = "spreadshot"
            pewpew.customizable_entity_set_string(selw,"Selected weapon: #dfdf40ffWide Shot")
        else
            weaponI = "main"
            pewpew.customizable_entity_set_string(selw,"Selected weapon: #40a0dfffFront Shot")
        end
        cooldown = 12
    end
    
    mulsc()
    
    pewpew.entity_set_position(ship_id,px,py-drag/4fx)
    if select(2,pewpew.entity_get_position(ship_id))<80fx then pewpew.entity_set_position(ship_id,px,80fx) end
    if select(2,pewpew.entity_get_position(ship_id))>640fx then pewpew.entity_set_position(ship_id,px,640fx) end
    pewpew.configure_player(0,{camera_x_override=rw,camera_y_override=rh-144fx})
    local conf=pewpew.get_player_configuration(0)
    if conf["has_lost"]==true then
        pewpew.stop_game()
    end
    
    local x = fmath.random_fixedpoint(8fx,width-8fx)
    local y = height-256fx
    if area == 1 then
        if t > 30 and t <= 240 then
            wave.type.randBAF(t, 12, x, y, 6fx)
        elseif t > 240 and t <= 450 then
            wave.type.mothership(t, 30, x, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t > 450  and t <= 690 then
            wave.type.randBAF(t, 8, x, y, 6fx)
        elseif t > 690  and t <= 900 then
            wave.type.wary(t, 12, x, y)
        elseif t == 1020 then
            pewpew.new_mothership(rw, height-256fx, pewpew.MothershipType.FOUR_CORNERS, wave.down)
        elseif t > 1050 and t <= 1170 then
            wave.type.randBAF(t, 4, x, y, 4fx)
        elseif t > 1170 and t <= 1260 then
            wave.type.crowder(t, 10, x, y, 3)
        elseif t > 1260 and t <= 1560 then
            wave.type.wary(t, 15, width-x, y)
            wave.type.crowder(t, 12, x, y, 1)
        elseif t > 1560 and t <= 1710 then
            wave.type.mothership(t, 21, x, y, pewpew.MothershipType.SIX_CORNERS)
        elseif t == 1740 then
            pewpew.new_mothership(rw/2fx, height-256fx, pewpew.MothershipType.FOUR_CORNERS, wave.down)
            pewpew.new_mothership(3fx*rw/2fx, height-256fx, pewpew.MothershipType.FOUR_CORNERS, wave.down)
        elseif t > 2010 and t <= 2100 then
            wave.type.popcorn(t, 6, width, "left", rh, ship_id, {12fx, -12fx, 0fx, 1fx})
        elseif t > 2130 and t <= 2220 then
            wave.type.popcorn(t, 6, width, "right", rh, ship_id, {12fx, -12fx, 0fx, 1fx})
        elseif t > 2250 and t <= 2340 then
            wave.type.popcorn(t, 6, width, "left", rh-144fx, ship_id, {12fx, 16fx, 0fx, -1fx/2fx})
        elseif t > 2370 and t <= 2460 then
            wave.type.popcorn(t, 6, width, "right", rh-144fx, ship_id, {12fx, 16fx, 0fx, -1fx/2fx})
        elseif t > 2490 and t <= 2580 then
            wave.type.popcorn(t, 3, width, "left", rh, ship_id, {12fx, -12fx, 0fx, 1fx})
            wave.type.popcorn(t, 3, width, "right", rh, ship_id, {12fx, -12fx, 0fx, 1fx})
        elseif t > 2610 and t <= 2700 then
            wave.type.popcorn(t, 3, width, "left", rh-144fx, ship_id, {12fx, 16fx, 0fx, -1fx/2fx})
            wave.type.popcorn(t, 3, width, "right", rh-144fx, ship_id, {12fx, 16fx, 0fx, -1fx/2fx})
        elseif t > 2730 and t <= 2790 then
            wave.type.mothership(t, 12, x, y, pewpew.MothershipType.SEVEN_CORNERS)
        elseif t > 2910 and t <= 3060 then
            wave.type.redBAF(t, 6, (x+rw)/2fx, y, 8fx)
        elseif t == 3090 then
            pewpew.new_mothership(rw, height-256fx, pewpew.MothershipType.FOUR_CORNERS, wave.down)
        elseif t > 3150 and t <= 3270 then
            wave.type.mothership(t, 15, x, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t > 3410 and getEnemyPresence() then
            txtcol = 0xff
            astI = "ast2"
            area = 2
            drag = drag + 2fx
            if mulBool then mul = mul + 1 end
            pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: " .. (mul+1)})
            mulBool = true
            for k=1,#bg do
                local x,y = pewpew.entity_get_position(bg[k])
                pewpew.entity_set_position(bg[k],x,y+1024fx)
                pewpew.customizable_entity_set_mesh_xyz_scale(bg[k],fmath.random_fixedpoint(8fx,32fx),1fx,fmath.random_fixedpoint(32fx,48fx))
                pewpew.customizable_entity_set_mesh(bg[k],"/dynamic/bg/grass.lua",0)
            end
            Time = t
            t = 1
            wave.customEnemies = {}
        end
    elseif area == 2 then
        if t > 60 and t <= 210 then
            local dx = fmath.random_fixedpoint(-4fx,4fx)
            wave.type.rngcorn(t, 3, (2fx*rw+x)/3fx, y, ship_id, {dx, 16fx, 0fx, 1fx/4fx}, (math.fsgn(dx)+6fx)*fmath.tau()/8fx)
            wave.type.mothership(t, 12, (rw+x)/2fx, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t > 270 and t <= 390 then
            wave.type.rngcorn(t, 2, 32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn(t, 2, width-32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 5fx*fmath.tau()/8fx)
        elseif t > 390 and t <= 540 then
            wave.type.rngcorn(t, 16, 32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn((t-8), 16, width-32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 5fx*fmath.tau()/8fx)
            wave.type.redBAF(t, 6, (2fx*rw+x)/3fx, y, 12fx)
        elseif t == 600 then
            VATER.new(rw, y, ship_id, 630, 4fx, 4fx, wave.down, rh, 255)
        elseif t > 930 and t <= 1140 then
            wave.type.bombing(t, 30, width, y, ship_id, 10, 2fx)
            wave.type.rngcorn(t, 18, 32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn((t-9), 18, width-32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 5fx*fmath.tau()/8fx)
        elseif t > 1200 and t <= 1260 then
            wave.type.redBAF(t, 6, (3fx*rw+x)/4fx, y, 16fx)
        elseif t == 1275 then
            pewpew.new_mothership(rw, height-256fx, pewpew.MothershipType.FOUR_CORNERS, wave.down)
        elseif t > 1410 and t <= 1500 then
            wave.type.mothership(t, 12, x, y, pewpew.MothershipType.FIVE_CORNERS)
            wave.type.rngcorn(t, 20, 32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn((t-10), 20, width-32fx, rh-128fx, ship_id, {-2fx, -28fx, 1fx/2fx, 1fx}, 5fx*fmath.tau()/8fx)
        elseif t > 1470 and t % 60 == 0 and t <= 1620 then
            wave.type.cubeRow(width,y,48)
        elseif t > 1710 and t <= 1740 then
            wave.type.mothership(t, 5, x, y, pewpew.MothershipType.SEVEN_CORNERS)
        elseif t > 1800 and t <= 1860 then
            wave.type.mothership(t, 12, x, y, pewpew.MothershipType.FIVE_CORNERS)
            wave.type.wary(t, 12, x, y)
        elseif t == 2100 then
            VATER.new(rw/2fx, y, ship_id, 270, -4fx, 8fx, wave.down, rh, 150)
            VATER.new(rw, y, ship_id, 270, 0fx, 2fx, wave.down, rh, 150)
            VATER.new(3fx*rw/2fx, y, ship_id, 270, 4fx, 8fx, wave.down, rh, 150)
        elseif t > 2580 and t <= 2670 then
            wave.type.mothership(t, 12, x, y, pewpew.MothershipType.FIVE_CORNERS)
            wave.type.rngcorn(t, 12, 32fx, rh-128fx, ship_id, {-4fx, -28fx, 1fx/2fx, 1fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn(t, 12, width-32fx, rh-128fx, ship_id, {-4fx, -28fx, 1fx/2fx, 1fx}, 5fx*fmath.tau()/8fx)
        elseif t > 2700 and t <= 2820 then
            wave.type.dirBAF(t, 3, x, y, fmath.atan2(y-py, x-px), 16fx)
        elseif t > 2910 and t <= 2970 then
            wave.type.popcorn(t, 3, width, "left", rh, ship_id, {12fx, 32fx, 0fx, -1fx})
            wave.type.popcorn(t, 3, width, "right", rh, ship_id, {12fx, 32fx, 0fx, -1fx})
        elseif t > 3000 and t < 3060 then
            wave.type.mothership(t, 6, x, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t == 3300 then
            VATER.new(rw/2fx, y, ship_id, 270, 4fx, 4fx, wave.down, rh+32fx, 150)
            VATER.new(3fx*rw/2fx, y, ship_id, 270, -4fx, 4fx, wave.down, rh-96fx, 150)
            wave.type.mothershipRow(width, y+fmath.random_fixedpoint(4fx,8fx), 144, pewpew.MothershipType.SIX_CORNERS)
        elseif t == 4020 then
            local boss = Mirrain.new(rw, height-256fx, ship_id, 1000, 2fx, 256fx, wave.down, rh)
            table.insert(wave.customEnemies,boss)
        elseif t > 4470 and getEnemyPresence() then
            txtcol = 0xff
            astI = "ast3"
            area = 3
            drag = drag + 2fx
            if mulBool then mul = mul + 1 end
            pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: " .. (mul+1)})
            mulBool = true
            for k=1,#bg do
                local x,y = pewpew.entity_get_position(bg[k])
                pewpew.entity_set_position(bg[k],x,y+1024fx)
                pewpew.customizable_entity_set_mesh_xyz_scale(bg[k],1fx,1fx,fmath.random_fixedpoint(-2fx,2fx))
                pewpew.customizable_entity_set_mesh(bg[k],"/dynamic/bg/p.lua",0)
            end
            Time = Time + t
            t = 1
            wave.customEnemies = {}
        end
    elseif area == 3 then
        if t == 60 then
            Eroship.new(rw, height, ship_id, 4000, 2fx, wave.down, height-288fx)
        elseif t > 90 and t % 180 == 0 and t <= 1230 then
            Tesser.new(rw, y, width, 384fx, rh, ship_id, 3, wave.down)
        elseif t > 1260 and t <= 1410 then
            local dx = fmath.random_fixedpoint(-2fx,2fx)
            wave.type.rngcorn(t, 3, (2fx*rw+x)/3fx, y, ship_id, {dx, 12fx, 0fx, 1fx/8fx}, (math.fsgn(dx)/2fx+3fx)*fmath.tau()/4fx)
        elseif t > 1440 and t <= 1530 then
            wave.type.mothership(t, 18, (rw+x)/2fx, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t > 1920 and t <= 2220 then
            wave.type.PPBAF(t, 15, x, y, ship_id, 6fx)
            wave.type.bombardment(t, 27, x, y, ship_id, 10, 4fx)
        elseif t > 2310 and t <= 2340 then
            wave.type.mothership(t, 5, x, y, pewpew.MothershipType.SEVEN_CORNERS)
        elseif t > 2460 and t <= 2640 then
            wave.type.PPBAF(t, 15, x, y, ship_id, 6fx)
            wave.type.mothership(t, 27, x, y, pewpew.MothershipType.SIX_CORNERS)
        elseif t > 2640 and t <= 2850 then
            wave.type.PPBAF(t, 9, x, y, ship_id, 6fx)
        elseif t > 2940 and t <= 3090 then
            local dx,dy = fmath.sincos(fmath.atan2(-24fx+px,y-py))
            dx=dx*24fx dy=dy*24fx
            wave.type.rngcorn(t, 3, 24fx, y, ship_id, {dx, dy-2fx, 0fx, 1fx/4fx}, 7fx*fmath.tau()/8fx)
            wave.type.rngcorn(t, 3, width-24fx, y, ship_id, {24fx*select(1,fmath.sincos(fmath.atan2(width-24fx-px,y-py))), dy-2fx, 0fx, 1fx/4fx}, 5fx*fmath.tau()/8fx)
        elseif t > 3120 and t <= 3210 then
            wave.type.rngcorn(t, 1, x, y, ship_id, {16fx, 24fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t > 3360 and getEnemyPresence() then
            txtcol = 0xff
            astI = "ast4"
            area = 4
            drag = drag + 4fx
            if mulBool then mul = mul + 1 end
            pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: " .. (mul+1)})
            mulBool = true
            for k=1,#bg do
                local x,y = pewpew.entity_get_position(bg[k])
                pewpew.entity_set_position(bg[k],x,y+1024fx)
            end
            Time = Time + t
            t = 1
            wave.customEnemies = {}
        end
    elseif area == 4 then
        if t > 60 and t <= 330 then
            wave.type.PPBAF(t, 2, x, y, ship_id, 8fx)
        elseif t > 330 and t <= 629 then
            wave.type.PPBAF(t, 9, x, y, ship_id, 8fx)
            if t % 90 == 0 then wave.type.cubeRow(width,y,32) end
        elseif t > 629 and t <= 1200 then
            wave.type.PPBAF(t, 5, x, y, ship_id, 8fx)
            wave.type.mothership(t, 59, x, y, pewpew.MothershipType.FIVE_CORNERS)
        elseif t > 1320 and t <= 1350 then
            wave.type.mothership(t, 3, x, y, pewpew.MothershipType.SEVEN_CORNERS)
        elseif t > 1560 and t <= 1680 then
            if t % 24 == 0 then wave.type.BAFrow(width, y, 32, 6fx) end
        elseif t > 1680 and t <= 1830 then
            wave.type.mothership(t, 72, x, y, pewpew.MothershipType.SIX_CORNERS)
            if t % 57 == 0 then wave.type.cubeRow(width,y,24) end
        elseif t > 1950 and t <= 2340 then
            wave.type.randBAF(t, 5, x, y, 4fx)
            wave.type.redBAF(t, 6, x, y, 4fx)
        elseif t == 2490 then
            local ee1 = VATER.new(rw/2fx, y, ship_id, 630, -4fx, 8fx, wave.down, rh, 255)
            local ee2 = VATER.new(3fx*rw/2fx, y, ship_id, 630, 4fx, 8fx, wave.down, rh, 255)
            local boss = Mirrain.new(rw, height-256fx, ship_id, 1500, 2fx, 240fx, wave.down, rh)
            table.insert(wave.customEnemies,ee1) table.insert(wave.customEnemies,ee2) table.insert(wave.customEnemies,boss)
        elseif t > 2910 and getEnemyPresence() then
            txtcol = 0xff
            astI = "ast5"
            area = 5
            drag = drag + 8fx
            if mulBool then mul = mul + 1 end
            pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: " .. (mul+1)})
            mulBool = true
            for k=#bg,1,-1 do
                pewpew.entity_destroy(bg[k])
                table.remove(bg,k)
            end
            for y=128,fmath.to_int(height),128 do
                local _=pewpew.new_customizable_entity(0fx,fmath.to_fixedpoint(y))
                pewpew.customizable_entity_set_mesh(_,"/dynamic/bg/a5bg.lua",0)
                pewpew.customizable_entity_set_position_interpolation(_,true)
                table.insert(bg,_)
            end
            for y=128,fmath.to_int(height),128 do
                local _=pewpew.new_customizable_entity(width,fmath.to_fixedpoint(y)-32fx)
                pewpew.customizable_entity_set_mesh(_,"/dynamic/bg/a5bg_r.lua",0)
                pewpew.customizable_entity_set_position_interpolation(_,true)
                table.insert(bg,_)
            end
            Time = Time + t
            t = 1
            wave.customEnemies = {}
        end
    elseif area == 5 then
        if t > 60 and t <= 210 then
            wave.type.rngcorn(t, 6, x, y, ship_id, {32fx, 40fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t > 210 and t <= 420 then
            wave.type.mothership(t, 15, x, y, pewpew.MothershipType.FIVE_CORNERS)
            wave.type.mothership(t, 31, x, y, pewpew.MothershipType.SIX_CORNERS)
        elseif t > 480 and t <= 810 then
            wave.type.mothership(t, 79, x, y, pewpew.MothershipType.FOUR_CORNERS)
            wave.type.redBAF(t, 6, (rw+x)/2fx, y, 8fx)
        elseif t > 1100 and t <= 1140 then
            wave.type.rngcorn(t, 5, x, y, ship_id, {32fx, 40fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t == 1290 then
            Erus.new(rw, height-256fx, ship_id, 1800, 2fx, wave.down, height-448fx)
        elseif t > 2160 and t <= 2310 then
            wave.type.randBAF(t, 3, (rw+x)/2fx, y, 16fx)
            wave.type.rngcorn(t, 5, x, y, ship_id, {28fx, 32fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t == 2490 then
            wave.type.mothershipRow(width, y+fmath.random_fixedpoint(4fx,8fx), 160, pewpew.MothershipType.FIVE_CORNERS)
            wave.type.mothershipRow(width, y+fmath.random_fixedpoint(4fx,8fx), 192, pewpew.MothershipType.SIX_CORNERS)
            VATER.new(rw/2fx, y, ship_id, 630, -4fx, 8fx, wave.down, rh, 255)
            VATER.new(3fx*rw/2fx, y, ship_id, 630, 4fx, 8fx, wave.down, rh, 255)
        elseif t == 3180 then
            Mirrain.new(rw-128fx, height-256fx, ship_id, 1000, 2fx, 64fx, wave.down, rh)
            Mirrain.new(rw+128fx, height-256fx, ship_id, 1000, 2fx, 64fx, wave.down, rh)
        elseif t > 4410 and t <= 4500 then
            wave.type.mothership(t, 18, x, y, pewpew.MothershipType.FIVE_CORNERS)
            if t % 30 == 0 then Tesser.new(rw, y, width, 384fx, rh, ship_id, 3, wave.down) end
        elseif t > 4590 and t <= 4650 then
            wave.type.mothership(t, 6, x, y, pewpew.MothershipType.SIX_CORNERS)
            wave.type.rngcorn(t, 5, x, y, ship_id, {28fx, 32fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t > 4740 and t <= 4770 then
            wave.type.rngcorn(t, 3, x, y, ship_id, {32fx, 40fx, 0fx, 0fx}, fmath.atan2(py-y,px-x))
        elseif t > 4800 and getEnemyPresence() then
            txtcol = 0xff
            astI = "ast6"
            area = 6
            drag = 4fx
            if mulBool then mul = mul + 1 end
            pewpew.configure_player_hud(0,{top_left_line="#00ffffffMultiplier: " .. (mul+1)})
            mulBool = true
            Time = Time + t
            t = 1
            wave.customEnemies = {}
        end
    elseif area == 6 then
        if t == 60 then
            Seteros.new(rw, 896fx, ship_id, 8000, 2fx, wave.down, height-448fx)
            local boss = Agonus.new(rw, 896fx, ship_id, 2000, 2fx, wave.down, height-448fx)
            table.insert(wave.customEnemies,boss)
        elseif t > 4320 and getEnemyPresence() then
            countdown=countdown-1
            if countdown==0 then Time=Time+t end
            if countdown%60==0 and countdown<0 and countdown>-720 then Alpha.new(x,0fx,fmath.random_fixedpoint(2fx,4fx)) end
            
            if countdown==-150 then Text.new(txt.one) end
            if countdown==-180 then Text.new(txt.two) end
            local Stats = txt.stats(pewpew.get_player_configuration(0).shield,mul+1,Time)
            if countdown==-270 then Text.new(Stats[1]) end
            if countdown==-300 then Text.new(Stats[2]) end
            if countdown==-330 then Text.new(Stats[3]) end
            if countdown==-360 then Text.new(Stats[4]) end
            
            if countdown==-480 then Text.new(txt.m) end
            if countdown==-540 then Text.new(txt.thr) end
            if countdown==-570 then Text.new(txt.JF) end
            if countdown==-600 then Text.new(txt.SKPG) end
            if countdown==-630 then Text.new(txt.ARTEM) end
            if countdown==-660 then Text.new(txt.MnHs) end
            if countdown==-690 then Text.new(txt.glebi) end
            if countdown==-720 then Text.new(txt.Kiwi) end
            
            if countdown==-1110 then
                pewpew.increase_score_of_player(0,5000*pewpew.get_player_configuration(0).shield)
                local End = pewpew.new_customizable_entity(rw,384fx)
                pewpew.customizable_entity_set_string(End,txt.Pewschatos)
                pewpew.customizable_entity_set_mesh_scale(End,2fx)
            end
            if countdown==-1230 then pewpew.add_damage_to_player_ship(ship_id,999) end
        end
    end
    
    if t%1560==0 and area~=5 and countdown==150 then
        bid = pewpew.new_bonus(fmath.random_fixedpoint(64fx,width-64fx),384fx,pewpew.BonusType.SHIELD,{box_duration=900})
        pewpew.add_arrow_to_player_ship(ship_id,bid,0xffff00ff)
    end
    if t%2580==0 and countdown==150 then
        pewpew.new_bomb(rw,y,pewpew.BombType.ATOMIZE)
    end
end
pewpew.add_update_callback(tick)