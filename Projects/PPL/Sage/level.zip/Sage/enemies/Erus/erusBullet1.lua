local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local EB1={}
function EB1.new(x,y,ship,dx,dy)
    local eb1=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(eb1,"/dynamic/enemies/Erus/bulletMesh1.lua",0)
    pewpew.customizable_entity_start_spawning(eb1,0)
    pewpew.entity_set_radius(eb1,10fx)
    pewpew.customizable_entity_set_position_interpolation(eb1,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    pewpew.entity_set_update_callback(eb1,function()
        t=t+1
        roll=roll+(fmath.abs_fixedpoint(dx)+dy)/32fx
        local ex,ey=pewpew.entity_get_position(eb1)
        if not dead then
            pewpew.entity_set_position(eb1, ex+dx, ey-dy)
            pewpew.customizable_entity_set_mesh_angle(eb1,roll,1fx,1fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(eb1,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(eb1,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(eb1,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(eb1,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(eb1,function()
        pewpew.customizable_entity_start_exploding(eb1,12)
        pewpew.add_damage_to_player_ship(ship,1)
        dead=true
    end)
end
return EB1