local ch=require("/dynamic/helpers/colorHelper.lua")

local col1 = 0x50201080
local col2 = 0x20501080

local verts = {}
local cols = {}
local segs = {}

local function shape(x,y)
    table.insert(verts, {x,y})
    table.insert(verts, {x,y+32,-24})
    table.insert(verts, {x+32,y,-24})
    table.insert(verts, {x,y-32,-24})
    table.insert(verts, {x-32,y,-24})
    table.insert(verts, {x-math.random(24,48),y+math.random(24,48),-math.random(16,32)})
    table.insert(verts, {x+math.random(24,48),y+math.random(24,48),-math.random(16,32)})
    table.insert(verts, {x+math.random(24,48),y-math.random(24,48),-math.random(16,32)})
    table.insert(verts, {x-math.random(24,48),y-math.random(24,48),-math.random(16,32)})
    
    local r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 128))
    r = math.random()
    table.insert(cols, ch.makeColor(80*r//1 + 32*(1-r)//1, 32*r//1 + 80*(1-r)//1, 16, 64))
    
    table.insert(segs, {#verts-9,#verts-8})
    table.insert(segs, {#verts-9,#verts-7})
    table.insert(segs, {#verts-9,#verts-6})
    table.insert(segs, {#verts-9,#verts-5})
    table.insert(segs, {#verts-8,#verts-7,#verts-6,#verts-5,#verts-8})
    table.insert(segs, {#verts-9,#verts-4})
    table.insert(segs, {#verts-9,#verts-3})
    table.insert(segs, {#verts-9,#verts-2})
    table.insert(segs, {#verts-9,#verts-1})
end

for x=48,1104,96 do shape(x,720) end
for x=48,1104,96 do shape(x,432) end
for x=48,1104,96 do shape(x,336) end
for x=48,1104,96 do shape(x,48) end
for x=48,240,96 do shape(x,624) end for x=528,624,96 do shape(x,624) end shape(1104,624)
for x=48,240,96 do shape(x,528) end for x=528,624,96 do shape(x,528) end for x=912,1104,96 do shape(x,528) end
for x=48,240,96 do shape(x,240) end for x=528,720,96 do shape(x,240) end shape(1008,240) shape(1104,240)
for x=48,240,96 do shape(x,144) end for x=528,624,96 do shape(x,144) end shape(1008,144) shape(1104,144)

meshes={{vertexes=verts, colors=cols, segments=segs}}