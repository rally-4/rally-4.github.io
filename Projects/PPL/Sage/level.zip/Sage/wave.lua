-- include any custom enemy
local WBAF = require("/dynamic/enemies/WBAF/WBAF.lua")

wave={}

-- table for custom enemy IDs upon spawn
wave.customEnemies={}

-- important directions
wave.right=0fx
wave.up=fmath.tau()/4fx
wave.left=fmath.tau()/2fx
wave.down=3fx*fmath.tau()/4fx
wave.directions={wave.right,wave.up,wave.left,wave.down}

-- wave functions
wave.type={}
wave.type.WBAF = function(width,height,dir,sparcity,s,ship)
    if dir==wave.right then
        for y=sparcity/2,fmath.to_int(height)-sparcity/2,sparcity do
            WBAF.new(0fx, fmath.to_fixedpoint(y), ship, s, wave.right)
        end
    elseif dir==wave.up then
        for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
            WBAF.new(fmath.to_fixedpoint(x), 0fx, ship, s, wave.up)
        end
    elseif dir==wave.left then
        for y=sparcity/2,fmath.to_int(height)-sparcity/2,sparcity do
            WBAF.new(width, fmath.to_fixedpoint(y), ship, s, wave.left)
        end
    elseif dir==wave.down then
        for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
            WBAF.new(fmath.to_fixedpoint(x), height, ship, s, wave.down)
        end
    end
end
wave.type.cubeRowX = function(width,y,sparcity)
    for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
        pewpew.new_rolling_cube(fmath.to_fixedpoint(x),y)
    end
end
return wave