local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local MB = require("/dynamic/enemies/Mirrain/mirrainBullet.lua")
local Mirrain={}
function Mirrain.new(x,y,ship,health,dy,scale,angle,ht)
    local mirrain=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Mirrain,mirrain)
    pewpew.customizable_entity_set_mesh(mirrain,"/dynamic/enemies/Mirrain/mesh.lua",0)
    pewpew.entity_set_radius(mirrain,64fx)
    pewpew.customizable_entity_set_position_interpolation(mirrain,true)
    local t = 0
    local MaxHP = {health}
    MaxHP = MaxHP[1]
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = false
    pewpew.entity_set_update_callback(mirrain,function()
        roll = roll + dy/64fx
        local ex, ey = pewpew.entity_get_position(mirrain)
        if not dead then
            if ey > ht and not activated then
                pewpew.entity_set_position(mirrain, ex, ey-dy)
            else
                t=t+1
                activated=true
                local tx,ty = fmath.sincos(fmath.to_fixedpoint(t)/30)
                pewpew.entity_set_position(mirrain, scale*tx+x, (scale*tx*ty)/2fx+ht)
                if t % 45 == 0 then
                    MB.new(ex, ey, ship, -3fx, 1fx-1fx/2fx)
                    MB.new(ex, ey, ship, -2fx, 2fx)
                    MB.new(ex, ey, ship, -1fx, 3fx+1fx/2fx)
                    MB.new(ex, ey, ship, 0fx, 4fx)
                    MB.new(ex, ey, ship, 1fx, 3fx+1fx/2fx)
                    MB.new(ex, ey, ship, 2fx, 2fx)
                    MB.new(ex, ey, ship, 3fx, 1fx-1fx/2fx)
                    if health < MaxHP/2 then
                        local px,py = pewpew.entity_get_position(ship)
                        local nx,ny = fmath.sincos(fmath.atan2(px-ex, py-ey))
                        for s=4,8 do
                            MB.new(ex, ey, ship, s*nx+fmath.random_fixedpoint(-1fx,1fx), -s*ny)
                        end
                    end
                end
            end
            pewpew.customizable_entity_set_mesh_angle(mirrain,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(mirrain,angle,1fx,0fx,0fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(mirrain,true,function(entity_id, wall_normal_x, wall_normal_y)
        
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(mirrain,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health-250
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health<1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(mirrain)),select(2,pewpew.entity_get_position(mirrain)),0xff8010ff,3fx,64)
                pewpew.customizable_entity_start_exploding(mirrain,30)
                pewpew.increase_score_of_player(0,10000)
                dead=true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(mirrain,function()
        pewpew.add_damage_to_player_ship(ship,10)
    end)
    return mirrain
end
return Mirrain