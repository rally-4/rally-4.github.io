meshes={{
    vertexes={{-360,-512,0},{-360,512,0},{360,512,0},{360,-512,0}},
    colors={0xffffff80,0xffffff80,0xffffff80,0xffffff80},
    segments={{0,1},{2,3}}
}}