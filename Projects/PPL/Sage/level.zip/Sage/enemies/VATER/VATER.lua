local eh = require("/dynamic/helpers/enemy_helpers.lua")
local ch = require("/dynamic/helpers/color_helpers.lua")
local VB = require("/dynamic/enemies/VATER/vaterBullet.lua")
local VATER={}
function VATER.new(x,y,ship,health)
    local vater=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.VATER,vater)
    pewpew.customizable_entity_set_mesh(vater,"/dynamic/enemies/VATER/mesh.lua",0)
    pewpew.entity_set_radius(vater,56fx)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = true
    pewpew.entity_set_update_callback(vater,function()
        t=t+1
        roll=-fmath.to_fixedpoint(t)/64fx
        local ex,ey=pewpew.entity_get_position(vater)
        if not dead and activated then
            pewpew.customizable_entity_set_mesh_angle(vater,roll,0fx,0fx,1fx)
            if t % 90 == 0 then
                local px,py = pewpew.entity_get_position(ship)
                local ang = fmath.atan2(py-ey, px-ex)
                local dy,dx = fmath.sincos(ang)
                dx=dx*32fx dy=dy*32fx
                VB.new(ex,ey,ship,2fx*select(2,fmath.sincos(ang-fmath.tau()/8fx)),2fx*select(1,fmath.sincos(ang-fmath.tau()/8fx)))
                for _=10,15 do VB.new(ex,ey,ship,dx/fmath.to_fixedpoint(_),dy/fmath.to_fixedpoint(_)) end
                VB.new(ex,ey,ship,2fx*select(2,fmath.sincos(ang+fmath.tau()/8fx)),2fx*select(1,fmath.sincos(ang+fmath.tau()/8fx)))
            end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(vater,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(vater,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION and not dead then
            pewpew.create_explosion(select(1,pewpew.entity_get_position(vater)),select(2,pewpew.entity_get_position(vater)),0x88ff88ff,2fx,32)
            pewpew.customizable_entity_start_exploding(vater,15)
            pewpew.increase_score_of_player(0,200)
            dead = true
        elseif weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health/2//1
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health=health-1
            if health < 1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(vater)),select(2,pewpew.entity_get_position(vater)),0x88ff88ff,1fx+1fx/2fx,32)
                pewpew.customizable_entity_start_exploding(vater,15)
                pewpew.increase_score_of_player(0,200)
                dead = true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(vater,function()
        if activated and not dead then
            pewpew.customizable_entity_start_exploding(vater,15)
            pewpew.add_damage_to_player_ship(ship,3)
            pewpew.increase_score_of_player(0,200)
            dead = true
        end
    end)
    return vater
end
return VATER