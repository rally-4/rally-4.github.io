local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={{
    vertexes={{-28,0,0},{28,0,0},{0,-28,0},{0,28,0},{0,0,-28},{0,0,28}},
    colors={0xdf4000df,0xdf4000df,0xdf4000df,0xdf4000df,0xdf4000df,0xdf4000df},
    segments={{0,1},{2,3},{4,5}}
}}
gfx.add_sphere(meshes[1],{0,0,0},0xdf400040,7)