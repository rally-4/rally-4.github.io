-- Set how large the level will be.
local width = 1200fx
local height = 1000fx
pewpew.set_level_size(width, height)

-- Create an entity at position (0,0) that will hold the background mesh.
local background = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(background, "/dynamic/rectangles_graphic.lua", 0)

local dots_background = pewpew.new_customizable_entity(0fx, 0fx)
pewpew.customizable_entity_set_mesh(dots_background, "/dynamic/random_dots.lua", 0)

-- Show a comment in the HUD
pewpew.configure_player_hud(0, {top_left_line = "#ff0000ffTime for the apocalypse."})

-- Create and configure the player's ship
pewpew.configure_player(0, {shield = 0})
local ship_id = pewpew.new_player_ship(width / 2fx, height / 2fx, 0)
pewpew.configure_player_ship_weapon(ship_id, {frequency = pewpew.CannonFrequency.FREQ_15, cannon = pewpew.CannonType.TRIPLE})

local time = 0
-- A function that will get called every game tick, which is 30 times per seconds.
function level_tick()
    time = time + 1
    pewpew.increase_score_of_player(0, 1)
    
    local conf = pewpew.get_player_configuration(0)
    if conf["has_lost"] == true then
        pewpew.stop_game()
    end
    
    if time % 10 == 0 then
        local x = fmath.random_fixedpoint(0fx, width)
        local y = fmath.random_fixedpoint(0fx, height)
        
        local sx = fmath.random_fixedpoint(0fx, width)
        local sy = fmath.random_fixedpoint(0fx, height)
        
        local c = fmath.random_int(0, 100)
        local sc = fmath.random_int(0, 100)
        
        if c < 95 then
            local angle = fmath.from_fraction(-1, 4) * fmath.tau()
            local baf_speed = fmath.random_fixedpoint(5fx, 10fx)
            pewpew.new_baf_red(x, y, angle, baf_speed, -1)
            pewpew.new_baf_red(width - x, y, angle, baf_speed, -1)
            pewpew.new_baf_red(x, height - y, -angle, baf_speed, -1)
            pewpew.new_baf_red(width - x, height - y, -angle, baf_speed, -1)
            
            pewpew.create_explosion(x, y, 0xff0000ff, 0.2047fx, 50)
            pewpew.create_explosion(width - x, y, 0xff0000ff, 0.2047fx, 50)
            pewpew.create_explosion(x, height - y, 0xff0000ff, 0.2047fx, 50)
            pewpew.create_explosion(width - x, height - y, 0xff0000ff, 0.2047fx, 50)
        elseif c < 99 then
            local angle = fmath.random_fixedpoint(0fx, fmath.tau())
            local acceleration = fmath.random_fixedpoint(0.2000fx, 1fx)
            pewpew.new_inertiac(x, y, acceleration, angle)
        elseif c < 100 then
            local angle = fmath.random_fixedpoint(0fx, fmath.tau())
            pewpew.new_mothership(x, y, pewpew.MothershipType.FOUR_CORNERS, angle)
        end
        
        if sc < 10 then
            local sangle = fmath.random_fixedpoint(0fx, fmath.tau())
            pewpew.new_rolling_sphere(sx, sy, sangle, 5fx)
        end
    end
end
pewpew.add_update_callback(level_tick)