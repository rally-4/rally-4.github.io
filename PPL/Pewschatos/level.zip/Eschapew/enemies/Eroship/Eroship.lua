local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local EB = require("/dynamic/enemies/Eroship/eroshipBullet.lua")
local Eroship={}
function Eroship.new(x,y,ship,health,dy,angle,ht)
    local eroship=pewpew.new_customizable_entity(x,y)
    EB.new(x, y, ship, 0fx, 8fx)
    eh.add_entity_to_type(eh.types.Eroship,eroship)
    pewpew.customizable_entity_set_mesh(eroship,"/dynamic/enemies/Eroship/mesh.lua",0)
    pewpew.entity_set_radius(eroship,256fx)
    pewpew.customizable_entity_set_position_interpolation(eroship,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = false
    pewpew.entity_set_update_callback(eroship,function()
        t = t+1
        roll = roll + 1fx/64fx
        local ex, ey = pewpew.entity_get_position(eroship)
        if not dead then
            pewpew.entity_set_position(eroship, ex, ey-dy)
            pewpew.customizable_entity_set_mesh_angle(eroship,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(eroship,angle,1fx,0fx,0fx)
            if ey < ht and not activated then dy=0fx activated=true end
            if t % 45 == 0 and activated then
                EB.new(ex, ey, ship, -3fx, 1fx)
                EB.new(ex, ey, ship, -2fx, 4fx)
                EB.new(ex, ey, ship, -1fx, 7fx)
                EB.new(ex, ey, ship, 0fx, 8fx)
                EB.new(ex, ey, ship, 1fx, 7fx)
                EB.new(ex, ey, ship, 2fx, 4fx)
                EB.new(ex, ey, ship, 3fx, 1fx)
            end
            if t % 120 == 0 and activated then
                local px,py = pewpew.entity_get_position(ship)
                local nx,ny = fmath.sincos(fmath.atan2(px-ex, py-ey))
                for s=12,14 do
                    EB.new(ex, ey, ship, s*nx+fmath.random_fixedpoint(-1fx,1fx), -s*ny)
                end
            end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(eroship,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(eroship,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health-250
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health<1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(eroship)),select(2,pewpew.entity_get_position(eroship)),0xff8010ff,4fx,96)
                pewpew.customizable_entity_start_exploding(eroship,60)
                pewpew.increase_score_of_player(0,20000)
                dead=true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(eroship,function()
        pewpew.add_damage_to_player_ship(ship,20)
    end)
end
return Eroship