meshes={{
    vertexes={{0,-8,0},{0,8,0},{-2,-8,0},{-2,8,0},{2,-8,0},{2,8,0},{0,-12,0},{0,12,0}},
    colors={0xffdf40ff,0xffdf40ff,0xffa000ff,0xffa000ff,0xffa000ff,0xffa000ff,0xffa000ff,0xffa000ff},
    segments={{0,1},{2,3},{4,5},{6,0},{1,7}}
}}