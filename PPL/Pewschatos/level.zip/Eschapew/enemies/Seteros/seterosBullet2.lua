local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local SB2={}
function SB2.new(x,y,ship,dx,dy)
    local sb2=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(sb2,"/dynamic/enemies/Seteros/bulletMesh2.lua",0)
    pewpew.customizable_entity_start_spawning(sb2,0)
    pewpew.entity_set_radius(sb2,6fx)
    pewpew.customizable_entity_set_position_interpolation(sb2,true)
    local t = 0
    local dead = false
    local roll = fmath.tau()
    pewpew.entity_set_update_callback(sb2,function()
        t=t+1
        roll=roll+(dx+dy)/64fx
        local ex,ey=pewpew.entity_get_position(sb2)
        if not dead then
            pewpew.entity_set_position(sb2,ex+dx,ey-dy)
            pewpew.customizable_entity_set_mesh_angle(sb2,roll,1fx,0fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(sb2,fmath.tau()/2fx,1fx,1fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(sb2,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(sb2,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(sb2,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(sb2,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(sb2,function()
        pewpew.customizable_entity_start_exploding(sb2,12)
        pewpew.add_damage_to_player_ship(ship,1)
        dead=true
    end)
end
return SB2