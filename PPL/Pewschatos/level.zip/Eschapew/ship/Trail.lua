local ch=require("/dynamic/helpers/color_helpers.lua")
local Trail={}
function Trail.new(x,y)
    local trail=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(trail,"/dynamic/ship/trailMesh.lua",0)
    pewpew.customizable_entity_start_spawning(trail,0)
    local yel=255
    local dead=false
    pewpew.entity_set_update_callback(trail,function()
        if not dead then
            yel=yel-10
            pewpew.customizable_entity_set_mesh_color(trail,ch.make_color(yel,yel,0,255))
            if yel<10 then dead=true pewpew.entity_destroy(trail) end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(trail,false,nil)
    return trail
end
return Trail