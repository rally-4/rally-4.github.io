local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local EB1 = require("/dynamic/enemies/Erus/erusBullet1.lua")
local EB2 = require("/dynamic/enemies/Erus/erusBullet2.lua")
local EB3 = require("/dynamic/enemies/Erus/erusBullet3.lua")
local Erus={}
function Erus.new(x,y,ship,health,dy,angle,ht)
    local erus=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Erus,erus)
    pewpew.customizable_entity_set_mesh(erus,"/dynamic/enemies/Erus/mesh.lua",0)
    pewpew.entity_set_radius(erus,64fx)
    pewpew.customizable_entity_set_position_interpolation(erus,true)
    local t = 0
    local MaxHP = {health}
    MaxHP = MaxHP[1]
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = false
    local attackPattern = 1
    pewpew.entity_set_update_callback(erus,function()
        roll = roll+dy/64fx
        local ex,ey = pewpew.entity_get_position(erus)
        if not dead then
            if ey > ht and not activated then
                pewpew.entity_set_position(erus, ex, ey-dy)
            else
                t=t+1
                activated=true
                local tx,ty = fmath.sincos(fmath.to_fixedpoint(t)/30)
                pewpew.entity_set_position(erus, ex, 64fx*tx*ty+ht)
                if attackPattern == 1 then
                    local x1 = fmath.random_fixedpoint(2fx,192fx)
                    local x2 = fmath.random_fixedpoint(576fx,766fx)
                    EB2.new(x1, 768fx, ship, 0fx, 16fx)
                    EB2.new(x2, 768fx, ship, 0fx, 16fx)
                end
                if t % 24 == 0 and t % 150 < 120 and attackPattern == 1 then
                    EB1.new(ex, ey, ship, -12fx+fmath.random_fixedpoint(-2fx,2fx), 8fx)
                    EB1.new(ex, ey, ship, -8fx+fmath.random_fixedpoint(-2fx,2fx), 12fx)
                    EB1.new(ex, ey, ship, -4fx+fmath.random_fixedpoint(-2fx,2fx), 14fx)
                    EB1.new(ex, ey, ship, 0fx+fmath.random_fixedpoint(-2fx,2fx), 16fx)
                    EB1.new(ex, ey, ship, 4fx+fmath.random_fixedpoint(-2fx,2fx), 14fx)
                    EB1.new(ex, ey, ship, 8fx+fmath.random_fixedpoint(-2fx,2fx), 12fx)
                    EB1.new(ex, ey, ship, 12fx+fmath.random_fixedpoint(-2fx,2fx), 8fx)
                elseif attackPattern == 2 then
                    local ang = fmath.random_fixedpoint(fmath.tau()/4fx,3fx*fmath.tau()/4fx)
                    EB3.new(ex, ey, ship, 8fx, ang)
                    if t%2==0 then EB3.new(ex, ey, ship, 12fx, -ang) end
                end
            end
            if health < MaxHP/4 then attackPattern=2 end
            pewpew.customizable_entity_set_mesh_angle(erus,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(erus,angle,1fx,0fx,0fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(erus,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(erus,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health-250
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health<1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(erus)),select(2,pewpew.entity_get_position(erus)),0xff8010ff,3fx,96)
                pewpew.customizable_entity_start_exploding(erus,30)
                pewpew.increase_score_of_player(0,20000)
                dead=true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(erus,function()
        pewpew.add_damage_to_player_ship(ship,50)
    end)
    return erus
end
return Erus