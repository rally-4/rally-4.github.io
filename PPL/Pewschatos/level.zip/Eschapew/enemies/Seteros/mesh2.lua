local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_sphere(meshes[1],{0,0,0},0xa00000ff,24)