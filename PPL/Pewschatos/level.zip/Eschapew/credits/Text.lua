local math = require("/dynamic/math.lua")
local rw=360fx
local Text={}
Text.new = function(str)
    local text=pewpew.new_customizable_entity(rw,0fx)
    pewpew.customizable_entity_set_string(text,str)
    pewpew.customizable_entity_start_spawning(text,0)
    local dead=false
    pewpew.entity_set_update_callback(text,function()
        if not dead then
            local ex,ey=pewpew.entity_get_position(text)
            pewpew.entity_set_position(text,ex,ey+2fx)
            if y>=1024fx then dead=true pewpew.entity_destroy(text) end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(text,false,nil)
end
return Text