local Acec={}
function Acec.new(x,y,col,func)
    local id=pewpew.new_customizable_entity(x,y)
    pewpew.entity_set_radius(id,96fx)
    pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/Acec/mesh.lua",0)
    pewpew.customizable_entity_set_mesh_color(id,col)
    local t=0
    pewpew.customizable_entity_start_spawning(id,0)
    pewpew.entity_set_update_callback(id,function()
        t = (t + 1) % 30
        pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/Acec/mesh.lua",t)
    end)
    pewpew.customizable_entity_set_player_collision_callback(id,function()
        pewpew.entity_destroy(id)
        func()
    end)
end
return Acec