-- Warning: contains waves with custom enemies
local BAF = require("/dynamic/enemies/BAF/BAF.lua")
local POC = require("/dynamic/enemies/POC/POC.lua")
local Bomber = require("/dynamic/enemies/Bomber/Bomber.lua")

wave={}
wave.customEnemies={}
wave.down=3fx*fmath.tau()/4fx

wave.type={}
wave.type.randBAF = function(t,den,x,y,s)
    if t % den == 0 then pewpew.new_baf(x,y,wave.down,s,-1) end
end
wave.type.dirBAF = function(t,den,x,y,ang,s)
    if t % den == 0 then pewpew.new_baf(x,y,ang,s,-1) end
end
wave.type.BAFrow = function(width,y,sparcity,s)
    for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
        pewpew.new_baf(fmath.to_fixedpoint(x),y,wave.down,s,-1)
    end
end
wave.type.redBAF = function(t,den,x,y,s)
    if t % den == 0 then pewpew.new_baf_red(x,y,wave.down,s,-1) end
end
wave.type.mothership = function(t,den,x,y,type)
    if t % den == 0 then pewpew.new_mothership(x,y,type,wave.down) end
end
wave.type.mothershipRow = function(width,y,sparcity,type)
    for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
        pewpew.new_mothership(fmath.to_fixedpoint(x),y,type,wave.down)
    end
end
wave.type.wary = function(t,den,x,y)
    if t % den == 0 then pewpew.new_wary(x,y) end
end
wave.type.crowder = function(t,den,x,y,q)
    if t % den == 0 then for _=0,q do pewpew.new_crowder(x,y) end end
end
wave.type.cubeRow = function(width,y,sparcity)
    for x=sparcity/2,fmath.to_int(width)-sparcity/2,sparcity do
        pewpew.new_rolling_cube(fmath.to_fixedpoint(x),y)
    end
end
wave.type.popcorn = function(t,den,width,side,y,id,params)
    if t % den == 0 then
        if side == "left" then
            local _=POC.new(4fx,y,id,params[1],params[2],params[3],params[4],7fx*fmath.tau()/8fx)
            table.insert(wave.customEnemies,_)
        else
            local _=POC.new(width-4fx,y,id,params[1],params[2],params[3],params[4],5fx*fmath.tau()/8fx)
            table.insert(wave.customEnemies,_)
        end
    end
end
wave.type.rngcorn = function(t,den,x,y,id,params,dir)
    if t % den == 0 then
        local _=POC.new(x,y,id,params[1],params[2],params[3],params[4],dir)
        table.insert(wave.customEnemies,_)
    end
end
wave.type.bombing = function(t,den,width,y,id,hp,s)
    if t % den == 0 then
        local _=Bomber.new(fmath.random_fixedpoint(64fx,96fx),y,id,hp,s,wave.down)
        table.insert(wave.customEnemies,_)
    elseif (t+den/2) % den == 0 then
        local _=Bomber.new(width-fmath.random_fixedpoint(32fx,64fx),y,id,hp,s,wave.down)
        table.insert(wave.customEnemies,_)
    end
end
wave.type.bombardment = function(t,den,x,y,id,hp,s)
    if t % den == 0 then
        local _=Bomber.new(x,y,id,hp,s,wave.down)
        table.insert(wave.customEnemies,_)
    end
end
wave.type.PPBAF = function(t,den,x,y,id,s)
    if t % den == 0 then
        BAF.new(x,y,id,s,wave.down)
    end
end
return wave