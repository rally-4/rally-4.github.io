local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local MB={}
function MB.new(x,y,ship,dx,dy)
    local mb=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(mb,"/dynamic/enemies/Mirrain/bulletMesh.lua",0)
    pewpew.customizable_entity_start_spawning(mb,0)
    pewpew.entity_set_radius(mb,14fx)
    pewpew.customizable_entity_set_position_interpolation(mb,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    pewpew.entity_set_update_callback(mb,function()
        t=t+1
        roll=roll+(fmath.abs_fixedpoint(dx)+dy)/32fx
        local ex,ey=pewpew.entity_get_position(mb)
        if not dead then
            pewpew.entity_set_position(mb, ex+dx, ey-dy)
            pewpew.customizable_entity_set_mesh_angle(mb,roll,1fx,1fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(mb,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(mb,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(mb,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(mb,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(mb,function()
        pewpew.customizable_entity_start_exploding(mb,12)
        pewpew.add_damage_to_player_ship(ship,1)
        dead=true
    end)
end
return MB