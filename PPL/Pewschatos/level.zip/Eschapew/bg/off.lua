local vertices = {}
local colors = {}
local segments = {}
local idx = 0
local col = 0x008000ff
for x=-512,0 do
    if (x+32) % 64 == 0 then
        table.insert(vertices,{x,0,1})
        table.insert(vertices,{x,1024,1})
        table.insert(colors,col)
        table.insert(colors,col)
        table.insert(segments,{idx,idx+1})
        idx=idx+2
    end
end
for y=0,1024 do
    if (y+32) % 64 == 0 then
        table.insert(vertices,{-512,y,1})
        table.insert(vertices,{0,y,1})
        table.insert(vertices,{720,y,1})
        table.insert(vertices,{1232,y,1})
        table.insert(colors,col)
        table.insert(colors,col)
        table.insert(colors,col)
        table.insert(colors,col)
        table.insert(segments,{idx,idx+1})
        table.insert(segments,{idx+2,idx+3})
        idx=idx+4
    end
end
for x=720,1232 do
    if (x+32) % 64 == 0 then
        table.insert(vertices,{x,0,1})
        table.insert(vertices,{x,1024,1})
        table.insert(colors,col)
        table.insert(colors,col)
        table.insert(segments,{idx,idx+1})
        idx=idx+2
    end
end
meshes={{
    vertexes=vertices,
    colors=colors,
    segments=segments
}}