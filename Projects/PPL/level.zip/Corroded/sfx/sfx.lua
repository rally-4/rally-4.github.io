local sfx={}
function sfx.bonus() pewpew.play_ambient_sound("/dynamic/sfx/sounds.lua",0) end
function sfx.hit() pewpew.play_ambient_sound("/dynamic/sfx/sounds.lua",1) end
function sfx.playerDeath() pewpew.play_ambient_sound("/dynamic/sfx/sounds.lua",2) end

function sfx.pew() pewpew.play_ambient_sound("/dynamic/sfx/sounds.lua",3) end
return sfx