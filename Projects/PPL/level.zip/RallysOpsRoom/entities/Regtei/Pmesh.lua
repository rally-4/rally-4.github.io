local cri = 0xad2648ff
local dcr = 0x75243aff
meshes={{
    vertexes={
        {-13,6},{-11,8},{-9,8},{-7,6},{-7,-6},{-9,-8},{-11,-8},{-13,-6},
        {-10,7},{-11,6},{-11,-6},{-10,-7},
        {-7,8},{-5,6},{-5,-6},{-7,-8}
    },
    colors={
        cri,cri,cri,cri,cri,cri,cri,cri,
        dcr,dcr,dcr,dcr,
        dcr,dcr,dcr,dcr
    },
    segments={
        {0,1,2,3,4,5,6,7,0},
        {8,9,10,11},
        {12,13,14,15}
    }
}}