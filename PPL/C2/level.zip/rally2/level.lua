local width = 768fx
local height = 1024fx
pewpew.set_level_size(width,height)

local background = pewpew.new_customizable_entity(width/2fx,height/2fx)
pewpew.customizable_entity_set_mesh(background,"/dynamic/rectangle.lua",0)

local noise = pewpew.new_customizable_entity(0fx,0fx)
pewpew.customizable_entity_set_mesh(noise,"/dynamic/p.lua",0)

pewpew.configure_player(0,{shield=3,move_joystick_color=0xefff80ff,shoot_joystick_color=0xffa020ff})
local ship_id = pewpew.new_player_ship(width/2fx,height/2fx,0)
pewpew.configure_player_ship_weapon(ship_id,{frequency=pewpew.CannonFrequency.FREQ_2,cannon=pewpew.CannonType.HEMISPHERE})

local t=0
local dif=1
local del=10
local thr=3600
function tick()
    t=t+1
    local conf=pewpew.get_player_configuration(0)
    if conf["has_lost"]==true then
        pewpew.stop_game()
    end
    if t % del == 0 then
        local x = fmath.random_fixedpoint(0fx,width)
        local y = fmath.random_fixedpoint(height-64fx,height-4fx)
        local ly = fmath.random_fixedpoint(4fx,64fx)
        local c = fmath.random_int(0,100)
        if c<50 then y=ly end
        if c < 92 then
            pewpew.create_explosion(x,y,0x00ff00ff,1fx,33)
            for i=0,dif,1 do
                pewpew.new_crowder(x,y)
            end
        elseif c < 98 then
            local angle=fmath.random_fixedpoint(0fx,fmath.tau())
            pewpew.new_mothership(x,y,pewpew.MothershipType.SIX_CORNERS,angle)
        elseif c < 100 then
            bid = pewpew.new_bonus(x,(height/2fx+y)/2fx,pewpew.BonusType.SHIELD,{box_duration=600})
            pewpew.add_arrow_to_player_ship(ship_id, bid, 0xffff00ff)
        end
    end
    if t % 900 == 0 then
        bid = pewpew.new_bonus(width/2fx,height/2fx,pewpew.BonusType.WEAPON,{box_duration=300,cannon=pewpew.CannonType.HEMISPHERE,frequency=pewpew.CannonFrequency.FREQ_30,weapon_duration=30})
        pewpew.add_arrow_to_player_ship(ship_id, bid, 0xffffffff)
    end
    if t % thr == 0 then
        del = del - 2
        thr = thr * 3
    end
    if t % 675 == 0 then
       dif = dif + 1
    end
end
pewpew.add_update_callback(tick)