local eh = require("/dynamic/helpers/enemy_helpers.lua")
local ch = require("/dynamic/helpers/color_helpers.lua")
local WBAF={}
function WBAF.new(x,y,ship,speed,angle)
    local wbaf=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.WBAF,wbaf)
    pewpew.customizable_entity_set_mesh(wbaf,"/dynamic/enemies/WBAF/meshes.lua",0)
    pewpew.entity_set_radius(wbaf,24fx)
    pewpew.customizable_entity_set_position_interpolation(wbaf,true)
    local t = 0
    local dy,dx = fmath.sincos(angle)
    local roll = fmath.tau()
    local dead = false
    local reduced = false
    local activated = false
    pewpew.entity_set_update_callback(wbaf,function()
        t=t+1
        roll=roll+speed/25fx
        local ex,ey = pewpew.entity_get_position(wbaf)
        if t==1 then
            pewpew.customizable_entity_add_rotation_to_mesh(wbaf,angle,0fx,0fx,1fx)
        end
        if t==30 then
            activated=true
        end
        if not dead and activated then
            pewpew.entity_set_position(wbaf,ex+(dx*speed),ey+(dy*speed))
            pewpew.customizable_entity_set_mesh_angle(wbaf,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(wbaf,angle,0fx,0fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(wbaf,true,function(entity_id,wall_normal_x,wall_normal_y)
        pewpew.customizable_entity_start_exploding(wbaf,15)
        dead = true
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(wbaf,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION and not reduced then
            pewpew.customizable_entity_set_mesh_color(wbaf,0x88ff88ff)
            reduced = true
            dx = dx / 2fx
            dy = dy / 2fx
        end
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not dead then
            pewpew.customizable_entity_start_exploding(wbaf,15)
            pewpew.increase_score_of_player(0,50)
            dead = true
        end
        if weapon_type == pewpew.WeaponType.BULLET and reduced and not dead then
            pewpew.customizable_entity_start_exploding(wbaf,15)
            pewpew.increase_score_of_player(0,50)
            dead = true
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(wbaf,function()
        if activated and not dead then
            pewpew.customizable_entity_start_exploding(wbaf,15)
            pewpew.add_damage_to_player_ship(ship,1)
            pewpew.increase_score_of_player(0,50)
            dead = true
        end
    end)
    return wbaf
end
return WBAF