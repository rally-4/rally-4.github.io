local helper={}
function helper.make_color(r,g,b,a)
    local col=r*256+g
    col=col*256+b
    col=col*256+a
    return col
end
function helper.make_color_with_alpha(color,new_alpha)
    local alpha = color % 256
    color = color - alpha + new_alpha
    return color
end
function helper.make_fx_color(r,g,b,a)
    local color = fmath.to_int(r) * 256 + fmath.to_int(g)
    color = color * 256 + fmath.to_int(b)
    color = color * 256 + fmath.to_int(a)
    return color
end
function helper.color_to_string(color)
    local s = string.format("%x",color)
    while string.len(s) < 8 do
        s = "0" .. s
    end
    return "#" .. s
end
return helper