local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_poly2(meshes[1],{0,0,0},8,0x88ff88ff,56,28,14)