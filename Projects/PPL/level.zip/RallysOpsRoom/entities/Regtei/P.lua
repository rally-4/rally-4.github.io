function P(x,y,ang)
    local id=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/Regtei/Pmesh.lua",0)
    pewpew.customizable_entity_set_mesh_angle(id,ang,0fx,0fx,1fx)
    pewpew.customizable_entity_skip_mesh_attributes_interpolation(id)
    pewpew.customizable_entity_start_spawning(id,0)
    local a=255
    pewpew.entity_set_update_callback(id,function() a=a-16
        pewpew.customizable_entity_set_mesh_color(id,0xffffff00+a)
        if a<16 then pewpew.entity_destroy(id) end
    end)
end
return P