local ch=require("/dynamic/helpers/color_helpers.lua")
local Trail=require("/dynamic/ship/Trail.lua")
local Alpha={}
function Alpha.new(x,y,dy)
    local alpha=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(alpha,"/dynamic/ship/alphaMesh.lua",0)
    pewpew.customizable_entity_add_rotation_to_mesh(alpha,-3fx*fmath.tau()/4fx,0fx,0fx,1fx)
    pewpew.customizable_entity_start_spawning(alpha,0)
    local dead=false
    pewpew.entity_set_update_callback(alpha,function()
        if not dead then
            local ex,ey=pewpew.entity_get_position(alpha)
            pewpew.entity_set_position(alpha,ex,ey+dy)
            local trail=Trail.new(ex,ey-6fx)
            pewpew.customizable_entity_set_mesh_xyz_scale(trail,1fx,dy,1fx)
            if y>=1024 then dead=true pewpew.entity_destroy(alpha) end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(alpha,false,nil)
    return alpha
end
return Alpha