local math = require("/dynamic/math.lua")
local txt={}
txt.one = "You defeated the #ff8800ffGeometric Erosion"
txt.two = "and restored peace to the Universe."
txt.stats = function(sh,mul,t)
    local sc=pewpew.get_score_of_player(0)
    return {"#a0efa0ffStatistics", "#00ffffffMultiplier#ffffffff: " .. mul, "#ffff80ffFinal score#ffffffff: " .. sc .. " + " .. sh*5000*mul, "#a0bfbfffExistence spanned for " .. math.floor(t/30) .. " seconds."}
end

txt.m = "Made by #0088ffffra#8888ffffll#ff88ffffy#ff8888ff4"
txt.thr= "Special thanks:"
txt.JF = "#0088ffffJ#ffff00ffF"
txt.SKPG = "#ff0000ffSKPG#ffffffff-#0000ffffTech"
txt.ARTEM = "#ffff00ffA#ff8800ffR#ff0000ffT#8800ffffE#0088ffffM#00ffffffI#00ff00ffY#ffffffffkra"
txt.MnHs = "#ffff88ffMn#0088ffffHs"
txt.glebi = "#8888ffffglebi#88ffffff5#88ff88ff7#ff88ffff4"
txt.Kiwi = "#8888ffffTasty Kiwi"

txt.Pewschatos = "#ff0000ff- #0012ccffPew#3858e8ffscha#507ff7fftos#ff0000ff -"
return txt