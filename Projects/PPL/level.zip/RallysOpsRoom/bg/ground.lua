local gfx=require("/dynamic/helpers/graphicHelper.lua")
meshes={{vertexes={},colors={},segments={}}}
for x=192,832,128 do
    for y=64,960,128 do
        gfx.addFlatPoly(meshes[1],{x,y,-8},4,0xffffff30,64,0)
    end
end
gfx.addFlatPoly(meshes[1],{64,832,-8},4,0xffffff30,64,0)
gfx.addFlatPoly(meshes[1],{960,832,-8},4,0xffffff30,64,0)
gfx.addFlatPoly(meshes[1],{960,192,-8},4,0xffffff30,64,0)
gfx.addFlatPoly(meshes[1],{64,192,-8},4,0xffffff30,64,0)