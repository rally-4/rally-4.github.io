local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_poly2(meshes[1],{0,0,0},10,0x8090a0ff,64,48,16)
gfx.add_sphere(meshes[1],{0,16,0},0x40bfbfbf,10.6665063229)
gfx.add_exstar2(meshes[1],{0,0,0},7,0x80808080,64,16)