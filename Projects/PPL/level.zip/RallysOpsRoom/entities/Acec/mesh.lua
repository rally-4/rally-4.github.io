local gfx=require("/dynamic/helpers/graphicHelper.lua")
meshes={}

local verts={}
local cols={}
local segs={}
for t=0,29 do
    for n=0,50,10 do
        local v = (n+t)%60
        table.insert(verts, {-64+v, 64-v, (.25*v)^2})
        table.insert(verts, {64-v, 64-v, (.25*v)^2})
        table.insert(verts, {64-v, -64+v, (.25*v)^2})
        table.insert(verts, {-64+v, -64+v, (.25*v)^2})
        
        table.insert(cols, 0xffffff00 - math.abs(6*v-192) + 192)
        table.insert(cols, 0xffffff00 - math.abs(6*v-192) + 192)
        table.insert(cols, 0xffffff00 - math.abs(6*v-192) + 192)
        table.insert(cols, 0xffffff00 - math.abs(6*v-192) + 192)
        
        table.insert(segs, {#verts-4, #verts-3, #verts-2, #verts-1, #verts-4})
    end
    table.insert(meshes,{vertexes=verts,colors=cols,segments=segs})
    verts,cols,segs={},{},{}
end