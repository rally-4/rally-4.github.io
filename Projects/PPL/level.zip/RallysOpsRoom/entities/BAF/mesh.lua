local gfx=require("/dynamic/helpers/graphicHelper.lua")
meshes={{vertexes={},colors={},segments={}}}
gfx.add_circle(meshes[1],{0,0,0},0xffffffff,24)
gfx.add_circle2(meshes[1],{0,0,0},0xffffffff,24)
gfx.add_circle3(meshes[1],{0,0,0},0xffffff80,24)