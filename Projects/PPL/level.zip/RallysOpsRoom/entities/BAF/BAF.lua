local BAF={}
-- PP2 BAFs have 7 hitpoints and give 3 score
function BAF.new(x,y,speed,angle)
    local id=pewpew.new_customizable_entity(x,y)
    pewpew.entity_set_radius(id,20fx)
    pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/BAF/mesh.lua",0)
    pewpew.customizable_entity_set_position_interpolation(id,true)
    pewpew.customizable_entity_skip_mesh_attributes_interpolation(id)
    local t,health,damage,dead=30,7,0,false
    local dy,dx=fmath.sincos(angle)
    local roll=0fx
    pewpew.customizable_entity_set_mesh_angle(id,roll,0fx,1fx,0fx)
    pewpew.customizable_entity_add_rotation_to_mesh(id,angle,0fx,0fx,1fx)
    pewpew.customizable_entity_start_spawning(id,0)
    pewpew.entity_set_update_callback(id,function()
        t = t - 1
        damage = damage - 1
        if t == 0 then pewpew.customizable_entity_set_mesh_color(id,0x32ff37ff) end
        if t < 1 then
            if damage < 0 then pewpew.customizable_entity_set_mesh_color(id,0x32ff37ff) else pewpew.customizable_entity_set_mesh_color(id,0xffffffff) end
            roll = roll + speed/25fx
            local x,y = pewpew.entity_get_position(id)
            local dying = pewpew.entity_get_is_started_to_be_destroyed(id)
            if dying then dead=true
                pewpew.increase_score_of_player(0,3)
                pewpew.create_explosion(x,y,0x32ff37ff,1fx/2fx,24)
                pewpew.customizable_entity_set_mesh_color(id,0x32ff37ff)
                pewpew.new_floating_message(x,y,"#32ff37ff3",{scale=1fx/2fx,dz=20fx,ticks_before_fade=5})
                pewpew.customizable_entity_configure_wall_collision(id,false,nil)
                pewpew.customizable_entity_set_weapon_collision_callback(id,nil)
                pewpew.entity_set_update_callback(id,nil)
                return 0
            end
            if not dead then
                pewpew.entity_set_position(id,x+(dx*speed),y+(dy*speed))
                pewpew.customizable_entity_set_mesh_angle(id,roll,0fx,1fx,0fx)
                pewpew.customizable_entity_add_rotation_to_mesh(id,angle,0fx,0fx,1fx)
                if health < 1 then
                    for _=1,pewpew.get_score_streak_level(0) do
                        pewpew.new_pointonium(x,y,128)
                    end
                    pewpew.increase_score_streak_of_player(0,150)
                    pewpew.customizable_entity_start_exploding(id,30)
                end
            end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(id,true,function(id,nx,ny)
        local dpm=((nx*dx)+(ny*dy))*2fx
        dx=dx-(nx*dpm)
        dy=dy-(ny*dpm)
        angle=fmath.atan2(dy,dx)
    end)
    pewpew.customizable_entity_set_player_collision_callback(id,function(id,player,ship)
        if not dead and t < 1 then
            pewpew.add_damage_to_player_ship(ship,1)
            pewpew.customizable_entity_start_exploding(id,30)
        end
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(id,function(id,player,weaponType)
        if weaponType==pewpew.WeaponType.BULLET and not dead then
            health=health-1 damage=2
        elseif weaponType==pewpew.WeaponType.ATOMIZE_EXPLOSION and not dead then
            pewpew.customizable_entity_start_exploding(id,30)
        end
        if not dead then return true end
    end)
    return id
end
return BAF