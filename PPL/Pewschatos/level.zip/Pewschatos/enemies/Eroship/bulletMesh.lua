meshes={{
    vertexes={{-12,0,0},{12,0,0},{0,-12,0},{0,12,0},{0,0,-12},{0,0,12}},
    colors={0xbf0040df,0xbf0040df,0xbf0040df,0xbf0040df,0xbf0040df,0xbf0040df},
    segments={{0,1},{2,3},{4,5}}
}}