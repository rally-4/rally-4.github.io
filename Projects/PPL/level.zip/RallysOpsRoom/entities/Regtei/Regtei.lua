local sfx=require("/dynamic/sfx/sfx.lua")
local math=require("/dynamic/math.lua")
local P=require("/dynamic/entities/Regtei/P.lua")
local Regtei={}
function Regtei.new(x,y)
    local id=pewpew.new_customizable_entity(x,y)
    pewpew.entity_set_radius(id,8fx)
    pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/Regtei/mesh.lua",0)
    pewpew.customizable_entity_set_angle_interpolation(id,true)
    pewpew.customizable_entity_set_position_interpolation(id,true)
    pewpew.customizable_entity_skip_mesh_attributes_interpolation(id)
    pewpew.customizable_entity_start_spawning(id,0)
    local colliding = false
    local stuckFactor = 0fx
    local t = 0
    pewpew.entity_set_update_callback(id,function() t=t+1
        local dying = pewpew.entity_get_is_started_to_be_destroyed(id)
        if dying then
            pewpew.create_explosion(x,y,0xad2648ff,1fx/2fx,16)
            pewpew.customizable_entity_configure_wall_collision(id,false,nil)
            pewpew.entity_set_update_callback(id,nil)
            return 0
        end
        local x,y = pewpew.entity_get_position(id)
        local l = pewpew.get_all_entities()
        local target = {nil,1024fx}
        for _,e in ipairs(l) do
            local type = pewpew.get_entity_type(e)
            if type~=pewpew.EntityType.CUSTOMIZABLE_ENTITY and type~=pewpew.EntityType.SHIP and type~=pewpew.EntityType.PLAYER_BULLET and type~=pewpew.EntityType.WARY_MISSILE and type~=pewpew.EntityType.MOTHERSHIP_BULLET and type~=pewpew.EntityType.UFO_BULLET then
                local ex,ey = pewpew.entity_get_position(e)
                local dst = ((ex-x)^2fx+(ey-y)^2fx)^(1fx/2fx)
                if dst < target[2] then target={e,dst} end
            end
        end
        if target[1] ~= nil then
            if colliding then colliding = false stuckFactor = stuckFactor + math.fpi/60fx else stuckFactor = 0fx end
            local tx,ty = pewpew.entity_get_position(target[1])
            local vx,vy = tx-x,ty-y
            ang = fmath.atan2(vy,vx)
            ang = ang + stuckFactor
            my,mx = fmath.sincos(ang)
            if target[2] > 96fx then
                x = x + mx*10fx
                y = y + my*10fx
                pewpew.entity_set_position(id,x,y)
                pewpew.customizable_entity_set_mesh_angle(id,ang,0fx,0fx,1fx)
            end
            if t%9==0 then P(x,y,ang) end
            if t%2==0 then sfx.pew()
                pewpew.new_player_bullet(x + mx*12fx, y - my*12fx, ang + fmath.random_fixedpoint(-math.fpi/12fx,math.fpi/12fx), 0)
            end
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(id,true,function(id,nx,ny)
        colliding = true
    end)
    return id
end
return Regtei