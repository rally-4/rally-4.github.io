math={}
function math.pi()
    return 3.141592653589793
end
function math.floor(a)
    return a//1
end
function math.remn(a)
    if a > 0 then
        return a
    else
        return 0
    end
end
function math.redn(a,r)
    if a < 0 then
        return a/r
    else
        return a
    end
end
function math.abs(a)
    if a < 0 then
        return -a
    else
        return a
    end
end
function math.impl(p,q)
    if p > q then
        return q
    else
        return p
    end
end
function math.hypot2(a,b)
    return (a^2+b^2)^0.5
end
function math.sgn(a)
    if a < 0 then return -1 else return 1 end
end
function math.fsgn(a)
    if a < 0fx then return -1fx else return 1fx end
end
return math