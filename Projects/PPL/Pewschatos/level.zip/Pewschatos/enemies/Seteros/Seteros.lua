local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local SB1 = require("/dynamic/enemies/Seteros/seterosBullet1.lua")
local SB2 = require("/dynamic/enemies/Seteros/seterosBullet2.lua")
local SB3 = require("/dynamic/enemies/Seteros/seterosBullet3.lua")
local Seteros={}
Seteros.patternAttack = function(ship,speed,sep,i)
    for _=sep,736,i do
        SB1.new(fmath.to_fixedpoint(_),768fx,ship,0fx,speed)
    end
end
Seteros.bhAttack = function(t,ex,ey,ship)
    local dx,dy=fmath.sincos(fmath.random_fixedpoint(3fx*fmath.tau()/4fx,5fx*fmath.tau()/4fx))
    SB2.new(ex,ey,ship,6fx*dx,6fx*dy)
    if t%2==0 then SB2.new(ex,ey,ship,-8fx*dx,8fx*dy) end
end
Seteros.playerAttack = function(ex,ey,ship)
    local px,py = pewpew.entity_get_position(ship)
    SB3.new(ex-96fx,ey,ship,16fx,fmath.atan2(px-ex+96fx,py-ey))
    SB3.new(ex,ey-96fx,ship,16fx,fmath.atan2(px-ex,py-ey+96fx))
    SB3.new(ex+96fx,ey,ship,16fx,fmath.atan2(px-ex-96fx,py-ey))
end
Seteros.mixedAttack = function(t,ex,ey,ship)
    if t % 2 == 0 then
        local dx,dy=fmath.sincos(fmath.random_fixedpoint(3fx*fmath.tau()/4fx,5fx*fmath.tau()/4fx))
        SB2.new(ex,ey,ship,6fx*dx,6fx*dy)
    end
    if t % 48 == 0 then Seteros.patternAttack(ship,8fx,128,128) end
    if (t+24) % 48 == 0 then Seteros.patternAttack(ship,8fx,64,128) end
end
function Seteros.new(x,y,ship,health,dy,angle,ht)
    local seteros=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Seteros,seteros)
    pewpew.customizable_entity_set_mesh(seteros,"/dynamic/enemies/Seteros/mesh.lua",0)
    pewpew.customizable_entity_set_mesh_xyz_scale(seteros,1fx+1fx/2fx,1fx+1fx/2fx,1fx)
    pewpew.entity_set_radius(seteros,120fx)
    pewpew.customizable_entity_set_position_interpolation(seteros,true)
    local t = 0
    local MaxHP = {health}
    MaxHP = MaxHP[1]
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = false
    local attackPattern = 3
    pewpew.entity_set_update_callback(seteros,function()
        roll = roll+dy/96fx
        local ex,ey = pewpew.entity_get_position(seteros)
        if not dead then
            if ey > ht and not activated then
                pewpew.entity_set_position(seteros, ex, ey-dy)
            else
                t=t+1
                activated=true
                if t % 300 == 0 then attackPattern=fmath.random_int(1,4) end
                if t % 300 < 210 then
                    if attackPattern == 1 and t % 54 == 0 then Seteros.patternAttack(ship,6fx,64,64) end
                    if attackPattern == 1 and (t+27) % 54 == 0 then Seteros.patternAttack(ship,6fx,32,64) end
                    if attackPattern == 2 then Seteros.bhAttack(t,ex,ey,ship) end
                    if attackPattern == 3 and t % 15 == 0 then Seteros.playerAttack(ex,ey,ship) end
                    if attackPattern == 4 then Seteros.mixedAttack(t,ex,ey,ship) end
                end
            end
            pewpew.customizable_entity_set_mesh_angle(seteros,roll,0fx,0fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(seteros,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(seteros,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health-500
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health<1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(seteros)),select(2,pewpew.entity_get_position(seteros)),0xa850b0ff,3fx,32)
                pewpew.customizable_entity_start_exploding(seteros,30)
                dead=true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(seteros,function()
        pewpew.add_damage_to_player_ship(ship,99)
    end)
    return seteros
end
return Seteros