local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local POC={}
function POC.new(x,y,ship,dx,dy,xaccel,yaccel,angle)
    local poc=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.POC,poc)
    pewpew.customizable_entity_set_mesh(poc,"/dynamic/enemies/POC/meshes.lua",0)
    pewpew.customizable_entity_start_spawning(poc,15)
    pewpew.entity_set_radius(poc,28fx)
    pewpew.customizable_entity_set_position_interpolation(poc,true)
    local t = 0
    local move_y, move_x = fmath.sincos(angle)
    local roll = fmath.tau()
    local dead = false
    local activated = false
    local g = 60
    local coloring = true
    pewpew.entity_set_update_callback(poc,function()
        t = t+1
        roll = roll + (dx + dy)/50fx
        local ex, ey = pewpew.entity_get_position(poc)
        if t == 5 then
            activated = true
        end
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(poc,angle,0fx,0fx,1fx)
        end
        if not dead and activated then
            dx = dx+xaccel
            dy = dy+yaccel
            pewpew.entity_set_position(poc,ex+(move_x*dx),ey+(move_y*dy))
            pewpew.customizable_entity_set_mesh_angle(poc,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(poc,angle,0fx,0fx,1fx)
        end
        if coloring then
            g=g+1
        else
            g=g-1
        end
        if g > 90 then
            coloring = false
        end
        if g < 30 then
            coloring = true
        end
        local r = 150
        local b = 255
        pewpew.customizable_entity_set_mesh_color(poc,color_helpers.make_color(r,g,b,255))
    end)
    pewpew.customizable_entity_configure_wall_collision(poc,true,function(entity_id,wall_normal_x,wall_normal_y)
        
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(poc,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.BULLET or weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION then
            pewpew.create_explosion(select(1,pewpew.entity_get_position(poc)),select(2,pewpew.entity_get_position(poc)),0x8040bfff,1fx,24)
            pewpew.customizable_entity_start_exploding(poc,15)
        end
        if weapon_type == pewpew.WeaponType.BULLET or weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION then
            pewpew.increase_score_of_player(0,10)
            pewpew.entity_destroy(poc)
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(poc,function()
        if activated then
            pewpew.customizable_entity_start_exploding(poc,15)
            pewpew.increase_score_of_player(0,10)
            pewpew.add_damage_to_player_ship(ship,1)
            dead = true
        end
    end)
    return poc
end
return POC