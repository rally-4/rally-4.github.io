local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={{
    vertexes={{-20,0,-8},{-16,16,8},{-16,-16,8},{-12,0,0},{0,12,0},{0,-12,0}},
    colors={0x20bf20bf,0x20bf20bf,0x20bf20bf,0x20bf20bf,0x20bf20bf,0x20bf20bf},
    segments={{0,3},{1,4},{2,5}}
}}
gfx.add_circle(meshes[1],{0,0,0},0x20bf20bf,12)