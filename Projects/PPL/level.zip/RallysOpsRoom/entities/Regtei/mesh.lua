local function invert(t)
    local result = {}
    for _,e in ipairs(t) do
        table.insert(result,{e[1],-e[2],e[3]})
    end
    return result
end

local appendage = {
    {-1,11,6},{1,9,5},{3,9,4},{5,7,3},{5,4,3},{7,2,2},{14,2},
    {5,12,5},{7,10,4},{8,7,3},{10,5,2},{13,5,1},
    {1,12,6},{8,12,4},{11,9,3},{12,9,2}
}
local iappendage = invert(appendage)

local ear = {
    {-3,14,4},{-7,14,2},{-9,13,2},{-8,11,2},{-5,8,4},
    {-4,9,4},
    {-3,12},{-4,13},{-5,12},{-4,11},{-3,10}
}
local iear = invert(ear)

local function insert(t1,t2)
    for i=1,#t2 do
        t1[#t1+1] = t2[i]
    end
end
local verts = appendage
insert(verts,iappendage)
insert(verts,ear)
insert(verts,iear)
insert(verts,{
    {-13,6,-6},{-11,8,-2},{-9,8,2},{-7,6,6},{-7,-6,6},{-9,-8,2},{-11,-8,-2},{-13,-6,-6},
    {-10,7,-4},{-11,6,-6},{-11,-6,-6},{-10,-7,-4},
    {-7,8,2},{-5,6,6},{-5,-6,6},{-7,-8,2},
    {0,4,2},{4,0,-2},{0,-4,2},{-4,0,-2}
})

local cri = 0xad2648ff
local gre = 0x6e6e6eff
local dcr = 0x75243aff
local lcr = 0xde3c5cff
meshes={{
    vertexes=verts,
    colors={
        cri,cri,cri,cri,cri,cri,cri,
        cri,cri,cri,cri,cri,
        cri,cri,cri,cri,
        cri,cri,cri,cri,cri,cri,cri,
        cri,cri,cri,cri,cri,
        cri,cri,cri,cri,
        
        gre,gre,gre,gre,gre, gre,
        gre,gre,gre,gre,gre,
        gre,gre,gre,gre,gre, gre,
        gre,gre,gre,gre,gre,
        
        cri,cri,cri,cri,cri,cri,cri,cri,
        dcr,dcr,dcr,dcr,
        dcr,dcr,dcr,dcr,
        lcr,lcr,lcr,lcr
    },
    segments={
        {0,1,2,3},{4,5,6},
        {7,8,9,10,11},
        {12,13,14,15},
        {16,17,18,19},{20,21,22},
        {23,24,25,26,27},
        {28,29,30,31},
        
        {32,33,34,35,36}, {35,37},
        {38,39},{38,40},{38,41},{38,42},
        {43,44,45,46,47}, {46,48},
        {49,50},{49,51},{49,52},{49,53},
        
        {54,55,56,57,58,59,60,61,54},
        {62,63,64,65},
        {66,67,68,69},
        {70,71,72,73,70}
    }
}}