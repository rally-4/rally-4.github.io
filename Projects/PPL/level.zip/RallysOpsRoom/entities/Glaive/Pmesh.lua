local gfx=require("/dynamic/helpers/graphicHelper.lua")
meshes={{vertexes={},colors={},segments={}}}
gfx.addCircle(meshes[1],{0,0,0},0xebb778ff,3.646716842,24)
gfx.addCircle(meshes[1],{0,0,0},0xffd17dff,1.823358421,24)