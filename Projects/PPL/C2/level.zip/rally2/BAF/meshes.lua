local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={gfx.new_mesh()}
gfx.add_circle(meshes[1],{0,0,0},0xffffffff,28)
gfx.add_circle2(meshes[1],{0,0,0},0xffffffff,28)
gfx.add_circle3(meshes[1],{0,0,0},0x808080ff,28)