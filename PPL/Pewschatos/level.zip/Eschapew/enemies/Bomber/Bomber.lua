local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local BB = require("/dynamic/enemies/Bomber/bomberBullet.lua")
local Bomber={}
function Bomber.new(x,y,ship,health,speed,angle)
    local bomber=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Bomber,bomber)
    pewpew.customizable_entity_set_mesh(bomber,"/dynamic/enemies/Bomber/mesh.lua",0)
    pewpew.entity_set_radius(bomber,32fx)
    pewpew.customizable_entity_set_position_interpolation(bomber,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    pewpew.entity_set_update_callback(bomber,function()
        t = t+1
        roll = roll + speed/64fx
        local ex, ey = pewpew.entity_get_position(bomber)
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(bomber,angle,1fx,0fx,0fx)
        end
        if not dead then
            pewpew.entity_set_position(bomber, ex, ey-speed)
            pewpew.customizable_entity_set_mesh_angle(bomber,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(bomber,angle,1fx,0fx,0fx)
            if t % 54 == 0 then
                local px, py = pewpew.entity_get_position(ship)
                BB.new(ex,ey,ship,6fx,fmath.atan2(px-ex, py-ey))
            end
        end
        pewpew.customizable_entity_set_mesh_color(bomber,color_helpers.make_color(255,255,255,255))
    end)
    pewpew.customizable_entity_configure_wall_collision(bomber,true,function(entity_id, wall_normal_x, wall_normal_y)
        
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(bomber,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION then
            pewpew.create_explosion(select(1,pewpew.entity_get_position(bomber)),select(2,pewpew.entity_get_position(bomber)),0xff8000ff,1fx,32)
            pewpew.customizable_entity_start_exploding(bomber,15)
            pewpew.increase_score_of_player(0,20)
            pewpew.entity_destroy(bomber)
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health - 1
            if health < 1 then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(bomber)),select(2,pewpew.entity_get_position(bomber)),0xff8000ff,1fx,32)
                pewpew.customizable_entity_start_exploding(bomber,15)
                pewpew.increase_score_of_player(0,20)
                pewpew.entity_destroy(bomber)
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(bomber,function()
        pewpew.customizable_entity_start_exploding(bomber,15)
        pewpew.increase_score_of_player(0,20)
        pewpew.add_damage_to_player_ship(ship,2)
        dead = true
    end)
    return bomber
end
return Bomber