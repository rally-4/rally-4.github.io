local sfx = require("/dynamic/sfx/sfx.lua")
local math=require("/dynamic/math.lua")
local P=require("/dynamic/entities/Glaive/P.lua")
local Glaive={}
function Glaive.new(ship,x,y)
    local id=pewpew.new_customizable_entity(x,y)
    pewpew.entity_set_radius(id,8fx)
    pewpew.customizable_entity_set_mesh(id,"/dynamic/entities/Glaive/mesh.lua",0)
    pewpew.customizable_entity_set_angle_interpolation(id,true)
    pewpew.customizable_entity_set_position_interpolation(id,true)
    pewpew.customizable_entity_skip_mesh_attributes_interpolation(id)
    pewpew.customizable_entity_start_spawning(id,0)
    local colliding = false
    local stuckFactor = 0fx
    local t = 0
    local ang = 0fx
    pewpew.entity_set_update_callback(id,function() t=t+1
        local dying = pewpew.entity_get_is_started_to_be_destroyed(id)
        if dying then
            pewpew.create_explosion(x,y,0xf5d049ff,1fx/2fx,16)
            pewpew.customizable_entity_configure_wall_collision(id,false,nil)
            pewpew.entity_set_update_callback(id,nil)
            return 0
        end
        local x,y = pewpew.entity_get_position(id)
        local px,py = pewpew.entity_get_position(ship)
        local vx,vy = px-x,py-y
        local dst = (vx^2fx+vy^2fx)^(1fx/2fx)
        if dst > 96fx then
            ang = fmath.atan2(vy,vx)
            if dst < 384fx and vx < 64fx and x > 64fx then ang = ang/16fx + math.fpi end
            if colliding then colliding = false stuckFactor = stuckFactor + math.fpi/60fx else stuckFactor = 0fx end
            ang = ang + stuckFactor
            local my,mx = fmath.sincos(ang)
            x = x + mx * math.min(13fx, dst - 64fx)
            y = y + my * math.min(13fx, dst - 64fx)
            pewpew.entity_set_position(id,x,y)
            pewpew.customizable_entity_set_mesh_angle(id,ang,0fx,0fx,1fx)
            if t%9==0 then P(x-10fx*mx,y+10fx*my) end
        end
        local _,_,sa,sd=pewpew.get_player_inputs(0)
        local nx,ny = fmath.sincos(ang)
        if t%6==0 and sd~=0fx then sfx.pew()
            pewpew.new_player_bullet(x + 10fx*nx, y + 8fx*ny, sa, 0)
        elseif t%6==3 and sd~=0fx then sfx.pew()
            pewpew.new_player_bullet(x - 10fx*nx, y - 8fx*ny, sa, 0)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(id,true,function(id,nx,ny)
        colliding = true
    end)
    return id
end
return Glaive