local math = require("/dynamic/math.lua")

Text = {idx = 1}

local function purify(str)
    str = str:gsub("\"", "") -- remove quotes
    str = str:gsub("\\", "")  -- remove backslashes
    str = str:gsub("#........", "")  -- remove rgba
    return str
end

local rh=768fx/2fx

local tab=28fx
local cust={}
function Text.remove()
    local l=pewpew.get_all_entities()
    for _,e in ipairs(l) do
        if cust[e]==1 then pewpew.entity_destroy(e) end
    end
end
function Text.column(obj)
    for i=1,#obj do
        local id=pewpew.new_customizable_entity(512fx,rh+tab*(#obj-1)/2-tab*(i-1))
        pewpew.customizable_entity_set_mesh_scale(id,7fx/8fx)
        pewpew.customizable_entity_set_string(id,obj[i])
        cust[id]=1
    end
end
function Text.newTalk(mesh1,mesh2)
    if mesh1[2]~=0 then
        local ts1=pewpew.new_customizable_entity(0fx,rh)
        if mesh1[2]<0 then mesh1[2]=-mesh1[2] pewpew.customizable_entity_set_mesh_angle(ts1,math.fpi,0fx,1fx,0fx) end
        pewpew.customizable_entity_set_mesh(ts1,mesh1[1],mesh1[2]-1)
        cust[ts1]=1
    end if mesh2[2]~=0 then
        local ts2=pewpew.new_customizable_entity(1024fx,rh)
        if mesh2[2]<0 then mesh2[2]=-mesh2[2] pewpew.customizable_entity_set_mesh_angle(ts2,math.fpi,0fx,1fx,0fx) end
        pewpew.customizable_entity_set_mesh(ts2,mesh2[1],mesh2[2]-1)
        cust[ts2]=1
    end
end

Text.obj = {
    {
        {"",0},{"/dynamic/talkSprites/Glaive.lua",2},
        {"#f5d049ff\"Rally, we have an incoming transmission!\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Glaive.lua",2},
        {"#0fbfffff\"Who's sending it?\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Glaive.lua",1},
        {"#f5d049ff\"Unknown. The signal cannot be traced either.\""}
    },
    {
        {"/dynamic/talkSprites/Regtei.lua",1},{"/dynamic/talkSprites/Glaive.lua",3},
        {"#ad2648ff\"oho~ I wonder who this poor soul is,", "#ad2648ffcalling us in the middle of the night...\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Glaive.lua",1},
        {"#0fdfffff\"Let's find out. Glaive, put it through.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Display.lua",1},
        {"Upon connecting with the caller,","the text \"Audio only\" appears on the hub's display."}
    },
        {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Display.lua",1},
        {"#c00000ff\"Hello there, boi.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",2},{"/dynamic/talkSprites/Display.lua",1},
        {"#0fdfffff\"That voice... Rilaz?!\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",2},{"/dynamic/talkSprites/Display.lua",1},
        {"#c00000ff\"Long time no see.","#c00000ffIt appears you are doing quite well, aren't you?\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",3},{"/dynamic/talkSprites/Display.lua",1},
        {"#0fdfffff\"In a way, yes. Freedom is all I've ever sought","#0fdfffffand it's what I finally got after years of struggle.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",4},{"/dynamic/talkSprites/Display.lua",1},
        {"#c00000ff\"Of course...","#c00000ffNow it is you the one who causes struggle to others instead.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",4},{"/dynamic/talkSprites/Display.lua",1},
        {"#0fdfffff\"What...?\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Display.lua",1},
        {"#c00000ff\"Don't play the fool.","#c00000ffYou have massacred countless innocent shapes.","#c00000ffBecause of you, my financial situation is worse than ever.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",5},{"/dynamic/talkSprites/Display.lua",1},
        {"#0fdfffff\"Listen, all I do is live in exile as a bounty haunter.","#0fdfffffThose shapes being in my way is not my problem.","#0fdfffffAll I have ever done is in self-defnse anyways.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",5},{"/dynamic/talkSprites/Display.lua",1},
        {"#c00000ff\"Still pretending that you're all innocent? Very well.","#c00000ffLet's see how good your ships are at 'self-defense'.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"",0},
        {"The call was abruptly ended."}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Glaive.lua",2},
        {"#f5d049ff\"A large group of entities is approaching from the south!\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",5},{"/dynamic/talkSprites/Glaive.lua",2},
        {"#0fdfffff\"Command all units to prepare for battle.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",4},{"/dynamic/talkSprites/Regtei.lua",-4},
        {"#ad2648ff\"They shall see boundless pain and insufferable nightmares.\""}
    },
    {
        {"/dynamic/talkSprites/Rally.lua",1},{"/dynamic/talkSprites/Regtei.lua",-5},
        {"#0fdfffff\"Yeah, anyhow...","#0fdfffffI'm afraid this won't be the last time we'll hear from Rilaz,","#0fdfffffeven if we do manage to defeat his goons.\""}
    }
}

return Text