local ch=require("/dynamic/helpers/colorHelper.lua")

local col1 = 0x50201080
local col2 = 0x20501080

local verts = {}
local cols = {}
local segs = {}

for a = -2*math.pi,2*math.pi,math.pi/16 do
    local i = 32+32*math.sin(a)
    local z = .25*a/math.pi
    table.insert(verts, {-i,768+i,256*z})
    table.insert(verts, {1152+i,768+i,256*z})
    table.insert(verts, {1152+i,-i,256*z})
    table.insert(verts, {-i,-i,256*z})
    
    local col = ch.makeColor(80*(z+.5)//1 + 32*(.5-z)//1, 32*(z+.5)//1 + 80*(.5-z)//1, 16, 128)
    table.insert(cols, col)
    table.insert(cols, col)
    table.insert(cols, col)
    table.insert(cols, col)
    
    table.insert(segs, {#verts-4, #verts-3, #verts-2, #verts-1, #verts-4})
end

meshes={{vertexes=verts, colors=cols, segments=segs}}