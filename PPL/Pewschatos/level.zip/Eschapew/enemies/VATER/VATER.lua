local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local VB = require("/dynamic/enemies/VATER/vaterBullet.lua")
local VATER={}
function VATER.new(x,y,ship,health,dx,dy,angle,ht,L)
    local vater=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.VATER,vater)
    pewpew.customizable_entity_set_mesh(vater,"/dynamic/enemies/VATER/mesh.lua",0)
    pewpew.entity_set_radius(vater,64fx)
    pewpew.customizable_entity_set_position_interpolation(vater,true)
    local t = 0
    local roll = fmath.tau()
    local tdx = 0fx
    local dir = 1fx
    local dead = false
    local crippled = false
    local activated = true
    pewpew.entity_set_update_callback(vater,function()
        t = t+1
        roll = roll + (tdx + dy)/64fx
        local ex, ey = pewpew.entity_get_position(vater)
        if t == 1 then
            pewpew.customizable_entity_add_rotation_to_mesh(vater,angle,1fx,0fx,0fx)
        end
        if not dead and activated then
            pewpew.entity_set_position(vater, ex+(dir*tdx), ey-dy)
            pewpew.customizable_entity_set_mesh_angle(vater,roll,0fx,1fx,0fx)
            pewpew.customizable_entity_add_rotation_to_mesh(vater,angle,1fx,0fx,0fx)
            if ey < ht then dy=0fx tdx=dx end
            if t % 60 == 0 then
                VB.new(ex,ey,ship,-4fx,9fx)
                for _=0,6 do VB.new(ex,ey,ship,0fx,12fx-fmath.to_fixedpoint(_)) end
                VB.new(ex,ey,ship,4fx,9fx)
            end
        end
        if t % 2 == 0 then pewpew.customizable_entity_set_mesh_color(vater,color_helpers.make_color(L,L,L,255)) end
    end)
    pewpew.customizable_entity_configure_wall_collision(vater,true,function(entity_id, wall_normal_x, wall_normal_y)
        dir = wall_normal_x * math.fsgn(tdx)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(vater,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            health = health-250
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            pewpew.customizable_entity_set_mesh_color(vater,color_helpers.make_color(255,255,255,255))
            health = health - 1
            if health < 1 then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(vater)),select(2,pewpew.entity_get_position(vater)),0xff8000ff,2fx,48)
                pewpew.customizable_entity_start_exploding(vater,15)
                pewpew.increase_score_of_player(0,500)
                pewpew.entity_destroy(vater)
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(vater,function()
        if activated then
            pewpew.customizable_entity_start_exploding(vater,15)
            pewpew.increase_score_of_player(0,500)
            pewpew.add_damage_to_player_ship(ship,5)
            dead = true
        end
    end)
end
return VATER