local col = 0xff000060

local verts = {}
local cols = {}
local segs = {}

local d = math.pi/32
for r=64,512,64 do
    for s=0,2*math.pi-math.pi/16,math.pi/8 do
        for o=s-d,s+d,d/4 do
            local x = r*math.cos(o)
            local y = -r*math.sin(o)
            table.insert(verts, {x,y})
            table.insert(cols, col)
            if o~=s-d then table.insert(segs, {#verts-2, #verts-1}) end
        end
    end
end

meshes={{vertexes=verts,colors=cols,segments=segs}}