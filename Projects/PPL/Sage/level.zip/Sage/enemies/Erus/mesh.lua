local gfx = require("/dynamic/helpers/graphic_helpers.lua")
meshes={{
    vertexes={{-64,0,0},{0,64,0},{64,0,0},{0,-64,0},{0,0,-64},{0,0,64}},
    colors={0xdfdf20ff,0xdfdf20ff,0xdfdf20ff,0xdfdf20ff,0xdfdf20ff,0xdfdf20ff},
    segments={{0,1,2,3,0},{0,5,2,4,0},{4,1,5,3,4}}
}}
gfx.add_sphere(meshes[1],{0,16,0},0x7000a0ff,16)
gfx.add_star2(meshes[1],{0,0,0},7,0xdfdf20ff,96,0)