local col = 0xc0c0c0ff

local verts = {}
local cols = {}
local segs = {}

function line(x1, y1, x2, y2)
    local x1sgn = (x1 > 0 and 1 or 0) - (x1 < 0 and 1 or 0)
    local y1sgn = (y1 > 0 and 1 or 0) - (y1 < 0 and 1 or 0)
    local x2sgn = (x2 > 0 and 1 or 0) - (x2 < 0 and 1 or 0)
    local y2sgn = (y2 > 0 and 1 or 0) - (y2 < 0 and 1 or 0)
    if math.abs(y1) == 256 then y1sgn = -y1sgn end
    if math.abs(y2) == 256 then y2sgn = -y2sgn end
    
    for z=0,64,8 do
        table.insert(verts, {x1 + x1sgn * z, y1 + y1sgn * z, z})
        table.insert(verts, {x2 + x2sgn * z, y2 + y2sgn * z, z})
        
        table.insert(cols, col - 2*z)
        table.insert(cols, col - 2*z)
        
        table.insert(segs, {#verts-2, #verts-1})
    end
end

local lines = {
    {-384, 512, 384, 512},
    {384, 512, 384, 384},
    {384, 384, 512, 384},
    {512, 384, 512, 256},
    {512, 256, 384, 256},
    {384, 256, 384, -256},
    {384, -256, 512, -256},
    {512, -256, 512, -384},
    {512, -384, 384, -384},
    {384, -384, 384, -512},
    {384, -512, -384, -512},
    {-384, -512, -384, -384},
    {-384, -384, -512, -384},
    {-512, -384, -512, -256},
    {-512, -256, -384, -256},
    {-384, -256, -384, 256},
    {-384, 256, -512, 256},
    {-512, 256, -512, 384},
    {-512, 384, -384, 384},
    {-384, 384, -384, 512}
}
for _,o in ipairs(lines) do
    line(o[1], o[2], o[3], o[4])
end

meshes={{vertexes=verts, colors=cols, segments=segs}}