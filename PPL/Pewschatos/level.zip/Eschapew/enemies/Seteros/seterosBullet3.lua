local SB3={}
function SB3.new(x,y,ship,speed,angle)
    local sb3=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(sb3,"/dynamic/enemies/Seteros/bulletMesh3.lua",0)
    pewpew.customizable_entity_start_spawning(sb3,0)
    pewpew.entity_set_radius(sb3,6fx)
    pewpew.customizable_entity_set_position_interpolation(sb3,true)
    local t=0
    local dx,dy=fmath.sincos(angle)
    dx = dx*speed
    dy = dy*speed
    local dead=false
    pewpew.entity_set_update_callback(sb3,function()
        t=t+1
        if t==1 then
            pewpew.customizable_entity_add_rotation_to_mesh(sb3,-angle,0fx,0fx,1fx)
        end
        local ex,ey=pewpew.entity_get_position(sb3)
        if not dead then
            pewpew.entity_set_position(sb3,ex+dx,ey+dy)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(sb3,true,function(entity_id,wall_normal_x,wall_normal_y)
        pewpew.customizable_entity_start_exploding(sb3,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(sb3,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(sb3,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(sb3,function()
        pewpew.customizable_entity_start_exploding(sb3,12)
        pewpew.add_damage_to_player_ship(ship,1)
        dead = true
    end)
end
return SB3