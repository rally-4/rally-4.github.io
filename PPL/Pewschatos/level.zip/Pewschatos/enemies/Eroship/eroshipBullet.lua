local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local EB={}
function EB.new(x,y,ship,dx,dy)
    local eb=pewpew.new_customizable_entity(x,y)
    pewpew.customizable_entity_set_mesh(eb,"/dynamic/enemies/Eroship/bulletMesh.lua",0)
    pewpew.customizable_entity_start_spawning(eb,0)
    pewpew.entity_set_radius(eb,6fx)
    pewpew.customizable_entity_set_position_interpolation(eb,true)
    local t = 0
    local roll = fmath.tau()
    local dead = false
    pewpew.entity_set_update_callback(eb,function()
        t=t+1
        roll=roll+(dx+dy)/64fx
        local ex,ey=pewpew.entity_get_position(eb)
        if not dead then
            pewpew.entity_set_position(eb, ex+dx, ey-dy)
            pewpew.customizable_entity_set_mesh_angle(eb,roll,1fx,1fx,1fx)
            pewpew.customizable_entity_add_rotation_to_mesh(eb,angle,0fx,0fx,1fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(eb,true,function(entity_id, wall_normal_x, wall_normal_y)
        pewpew.customizable_entity_start_exploding(eb,12)
    end)
    pewpew.customizable_entity_set_weapon_collision_callback(eb,function(entity_id, player_index, weapon_type)
        if weapon_type == pewpew.WeaponType.FREEZE_EXPLOSION then
            pewpew.customizable_entity_start_exploding(eb,12)
        end
        if weapon_type == pewpew.WeaponType.BULLET then
            return false
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(eb,function()
        pewpew.customizable_entity_start_exploding(eb,12)
        pewpew.add_damage_to_player_ship(ship,2)
        dead=true
    end)
end
return EB