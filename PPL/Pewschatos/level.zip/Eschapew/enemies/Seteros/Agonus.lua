local eh = require("/dynamic/helpers/enemy_helpers.lua")
local color_helpers = require("/dynamic/helpers/color_helpers.lua")
local SB1 = require("/dynamic/enemies/Seteros/seterosBullet1.lua")
local SB2 = require("/dynamic/enemies/Seteros/seterosBullet2.lua")
local SB3 = require("/dynamic/enemies/Seteros/seterosBullet3.lua")
local Agonus={}
Agonus.scaledHell = function(ex,ey,ship)
    local dx,dy=fmath.sincos(fmath.random_fixedpoint(3fx*fmath.tau()/4fx,5fx*fmath.tau()/4fx))
    local rad=fmath.to_fixedpoint(fmath.random_int(4,12))
    local b=SB1.new(ex,ey,ship,48fx/rad*dx,48fx/rad*dy)
    pewpew.entity_set_radius(b,rad)
    rad=rad/6fx
    pewpew.customizable_entity_set_mesh_scale(b,rad)
    pewpew.customizable_entity_set_mesh_color(b,0x80808080)
end
Agonus.radialHell = function(ex,ey,ship)
    local dx,dy=fmath.sincos(fmath.random_fixedpoint(fmath.tau()/4fx,5fx*fmath.tau()/4fx))
    SB2.new(ex,ey,ship,8fx*dx,8fx*dy)
    SB2.new(ex,ey,ship,-10fx*dx,10fx*dy)
end
function Agonus.new(x,y,ship,health,dy,angle,ht)
    local agonus=pewpew.new_customizable_entity(x,y)
    eh.add_entity_to_type(eh.types.Agonus,agonus)
    pewpew.customizable_entity_set_mesh(agonus,"/dynamic/enemies/Seteros/mesh2.lua",0)
    pewpew.customizable_entity_set_mesh_xyz_scale(agonus,3fx/4fx,1fx,3fx/4fx)
    pewpew.entity_set_radius(agonus,96fx)
    pewpew.customizable_entity_set_position_interpolation(agonus,true)
    local t = 0
    local MaxHP = {health}
    MaxHP = MaxHP[1]
    local roll = fmath.tau()
    local dead = false
    local crippled = false
    local activated = false
    local attackPattern = 1
    pewpew.entity_set_update_callback(agonus,function()
        roll = roll+dy/96fx
        local ex,ey = pewpew.entity_get_position(agonus)
        if not dead then
            if health < MaxHP then activated=true end
            if ey > ht and not activated then
                pewpew.entity_set_position(agonus, ex, ey-dy)
            elseif activated then
                t=t+1
                pewpew.customizable_entity_add_rotation_to_mesh(agonus,angle,1fx,0fx,0fx)
                if t % 240 == 0 then attackPattern=fmath.random_int(1,2) end
                if attackPattern == 1 then Agonus.scaledHell(ex,ey,ship) end
                if attackPattern == 2 then Agonus.radialHell(ex,ey,ship) end
            end
            pewpew.customizable_entity_set_mesh_angle(agonus,roll,0fx,0fx,1fx)
            pewpew.customizable_entity_add_rotation_to_mesh(agonus,angle,1fx,0fx,0fx)
        end
    end)
    pewpew.customizable_entity_configure_wall_collision(agonus,false,nil)
    pewpew.customizable_entity_set_weapon_collision_callback(agonus,function(entity_id,player_index,weapon_type)
        if weapon_type == pewpew.WeaponType.ATOMIZE_EXPLOSION and not crippled then
            crippled = true
            return false
        elseif weapon_type == pewpew.WeaponType.BULLET then
            health = health-1
            if health<1 and not dead then
                pewpew.create_explosion(select(1,pewpew.entity_get_position(agonus)),select(2,pewpew.entity_get_position(agonus)),0xa00000ff,4fx,96)
                pewpew.customizable_entity_start_exploding(agonus,45)
                pewpew.increase_score_of_player(0,100000)
                dead=true
            end
        end
        if not dead then
            return true
        end
    end)
    pewpew.customizable_entity_set_player_collision_callback(agonus,function()
        pewpew.add_damage_to_player_ship(ship,999)
    end)
    return agonus
end
return Agonus