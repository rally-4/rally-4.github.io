local gfx=require("/dynamic/helpers/graphicHelper.lua")
meshes={{vertexes={},colors={},segments={}}}

function addCircle(mesh, C, col, r, n)
    local x = C[1]
    local y = C[2]
    local z = C[3]
    local verts = {}
    local cols = {}
    local m = 2*math.pi/n
    for i=0,n do
        table.insert(verts, {x + r*math.cos(m*i), y + r*math.sin(m*i), z})
        table.insert(cols, col)
    end
    gfx.add_line_to_mesh(mesh, verts, cols)
end
function pillar(x,y)
    for z=0,56,8 do
        addCircle(meshes[1], {x,y,2*z}, math.min(0xff00ff + 0x0500*z, 0xffffff), 48-3*z/4, 16)
    end
end

-- OUTER CONES
pillar(64,960)
pillar(192,960)

pillar(64,192)
pillar(64,64)

pillar(832,320)
pillar(960,320)
pillar(832,192)
pillar(960,192)
pillar(832,64)
pillar(960,64)

-- INNER CONES
pillar(640,832)
pillar(640,704)
pillar(768,704)

pillar(384,640)
pillar(384,512)
pillar(256,384)
pillar(384,384)